export default function sectionToCategory(section) {
    if(section === "university") return 4;
    else if(section === "menagerie") return 8;
    else if(section === "sports") return 6;
    else if(section === "vanguard") return 1883;
    else if(section === "opinion") return 5;
    else null;
}