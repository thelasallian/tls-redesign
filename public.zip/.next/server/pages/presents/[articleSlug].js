(() => {
var exports = {};
exports.id = 438;
exports.ids = [438];
exports.modules = {

/***/ 7567:
/***/ ((module) => {

// Exports
module.exports = {
	"body__wrapper__full": "Body_body__wrapper__full__Erliu",
	"body__background__wrapper": "Body_body__background__wrapper__VDKie",
	"background__image__img": "Body_background__image__img__zr6fl",
	"body__foreground__wrapper": "Body_body__foreground__wrapper__MVVPi",
	"body__information__wrapper": "Body_body__information__wrapper__UewMz",
	"body__headline__wrapper": "Body_body__headline__wrapper__KZaef",
	"body__author__wrapper": "Body_body__author__wrapper__u9fUg",
	"body__date__wrapper": "Body_body__date__wrapper__ESi6y",
	"body__content__wrapper": "Body_body__content__wrapper__yyNXG",
	"body__suggestions__wrapper": "Body_body__suggestions__wrapper__DVh0e",
	"suggestions__header__wrapper": "Body_suggestions__header__wrapper__CRIYu",
	"suggestions__articles__wrapper": "Body_suggestions__articles__wrapper__OPIpm",
	"university": "Body_university__HtYfB",
	"menagerie": "Body_menagerie__XP2wo",
	"sports": "Body_sports__Iy8fG",
	"vanguard": "Body_vanguard__0bL_B",
	"opinion": "Body_opinion__5A_yZ"
};


/***/ }),

/***/ 146:
/***/ ((module) => {

// Exports
module.exports = {
	"footer__wrapper__full": "Footer_footer__wrapper__full__kUzjH",
	"socials__wrapper__list": "Footer_socials__wrapper__list__Ed9_U",
	"socials__icon__facebook": "Footer_socials__icon__facebook__xyYD_",
	"socials__icon__svg": "Footer_socials__icon__svg__SuvOY",
	"footer__details__wrapper": "Footer_footer__details__wrapper__HyJeJ",
	"details__text__container": "Footer_details__text__container__5buig",
	"ender__details__wrapper": "Footer_ender__details__wrapper__HEJFo",
	"ender__toTheTop__link": "Footer_ender__toTheTop__link__sxT4s"
};


/***/ }),

/***/ 7068:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ArticlePage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/HeaderV2/Header.js + 3 modules
var Header = __webpack_require__(5613);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./styles/Body/article/Body.module.scss
var Body_module = __webpack_require__(7567);
var Body_module_default = /*#__PURE__*/__webpack_require__.n(Body_module);
// EXTERNAL MODULE: ./components/ArticleCards/card__out/ArticleCard.js
var ArticleCard = __webpack_require__(5266);
// EXTERNAL MODULE: ./components/Functions/createAuthorsList.js
var createAuthorsList = __webpack_require__(1477);
;// CONCATENATED MODULE: ./components/Functions/parseRelatedArticles.js
function parseRelatedArticles(relatedArticles) {
    const parsedArticles = relatedArticles.map((article)=>{
        const indexAdder = 16;
        const startOfSlugIndex = article.url.indexOf(".com/") + indexAdder;
        const slug = article.url.substring(startOfSlugIndex, article.url.length - 1);
        const excerpt = article.excerpt;
        const title = article.title;
        const jetpack_featured_media_url = article.img["src"];
        return {
            title: {
                ["rendered"]: title
            },
            authors: null,
            excerpt: {
                ["rendered"]: excerpt
            },
            slug: slug,
            jetpack_featured_media_url: jetpack_featured_media_url
        };
    });
    return parsedArticles;
}

// EXTERNAL MODULE: ./components/Functions/dehtml.js
var dehtml = __webpack_require__(5054);
// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__(1635);
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_);
;// CONCATENATED MODULE: ./components/Body/article/Body.js








function Body({ article , section  }) {
    const headline = (0,dehtml/* default */.Z)(article.title["rendered"]);
    const authorsList = (0,createAuthorsList/* default */.Z)(article.authors, "link");
    const dateCreated = external_dayjs_default()(article.date).format("MMMM D, YYYY");
    const relatedArticles = parseRelatedArticles(article["jetpack-related-posts"].slice(0, 3));
    const relatedArticlesCard = relatedArticles.map((article)=>/*#__PURE__*/ jsx_runtime_.jsx(ArticleCard/* default */.Z, {
            article: article,
            hasSnippet: false,
            hasAuthor: false,
            hasImage: true
        }, `${article.slug}-articleCard`));
    const setBackgroundColor = ()=>{
        if (section === "University") return (Body_module_default()).university;
        else if (section === "Menagerie") return (Body_module_default()).menagerie;
        else if (section === "Sports") return (Body_module_default()).sports;
        else if (section === "Vanguard") return (Body_module_default()).vanguard;
        else if (section === "Opinion") return (Body_module_default()).opinion;
        else return null;
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Body_module_default()).body__wrapper__full,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${(Body_module_default()).body__background__wrapper} ${setBackgroundColor()}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: (Body_module_default()).background__image__img,
                    src: article.jetpack_featured_media_url
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Body_module_default()).body__foreground__wrapper,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Body_module_default()).body__information__wrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Body_module_default()).body__headline__wrapper,
                                children: headline
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Body_module_default()).body__author__wrapper,
                                children: [
                                    "by ",
                                    authorsList
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Body_module_default()).body__date__wrapper,
                                children: dateCreated
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Body_module_default()).body__content__wrapper,
                        dangerouslySetInnerHTML: {
                            __html: article.content.rendered
                        }
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Body_module_default()).body__suggestions__wrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Body_module_default()).suggestions__header__wrapper,
                                children: "Related posts"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Body_module_default()).suggestions__articles__wrapper,
                                children: relatedArticlesCard
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./styles/Footer/Article/Footer.module.scss
var Footer_module = __webpack_require__(146);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: ./components/Footer/Article/Footer.js



function FooterFull() {
    const goToTheTop = ()=>{
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    const tlsCreationDate = external_dayjs_default()("1960-10-24");
    const currentDate = external_dayjs_default()();
    const tlsEra = currentDate.diff(tlsCreationDate, "year");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Footer_module_default()).footer__wrapper__full,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).socials__wrapper__list,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://facebook.com/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (Footer_module_default()).socials__icon__facebook,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M17.525,9H14V7c0-1.032,0.084-1.682,1.563-1.682h1.868v-3.18C16.522,2.044,15.608,1.998,14.693,2 C11.98,2,10,3.657,10,6.699V9H7v4l3-0.001V22h4v-9.003l3.066-0.001L17.525,9z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://instagram.com/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (Footer_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M 8 3 C 5.239 3 3 5.239 3 8 L 3 16 C 3 18.761 5.239 21 8 21 L 16 21 C 18.761 21 21 18.761 21 16 L 21 8 C 21 5.239 18.761 3 16 3 L 8 3 z M 18 5 C 18.552 5 19 5.448 19 6 C 19 6.552 18.552 7 18 7 C 17.448 7 17 6.552 17 6 C 17 5.448 17.448 5 18 5 z M 12 7 C 14.761 7 17 9.239 17 12 C 17 14.761 14.761 17 12 17 C 9.239 17 7 14.761 7 12 C 7 9.239 9.239 7 12 7 z M 12 9 A 3 3 0 0 0 9 12 A 3 3 0 0 0 12 15 A 3 3 0 0 0 15 12 A 3 3 0 0 0 12 9 z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://twitter.com/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (Footer_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M22,3.999c-0.78,0.463-2.345,1.094-3.265,1.276c-0.027,0.007-0.049,0.016-0.075,0.023c-0.813-0.802-1.927-1.299-3.16-1.299 c-2.485,0-4.5,2.015-4.5,4.5c0,0.131-0.011,0.372,0,0.5c-3.353,0-5.905-1.756-7.735-4c-0.199,0.5-0.286,1.29-0.286,2.032 c0,1.401,1.095,2.777,2.8,3.63c-0.314,0.081-0.66,0.139-1.02,0.139c-0.581,0-1.196-0.153-1.759-0.617c0,0.017,0,0.033,0,0.051 c0,1.958,2.078,3.291,3.926,3.662c-0.375,0.221-1.131,0.243-1.5,0.243c-0.26,0-1.18-0.119-1.426-0.165 c0.514,1.605,2.368,2.507,4.135,2.539c-1.382,1.084-2.341,1.486-5.171,1.486H2C3.788,19.145,6.065,20,8.347,20 C15.777,20,20,14.337,20,8.999c0-0.086-0.002-0.266-0.005-0.447C19.995,8.534,20,8.517,20,8.499c0-0.027-0.008-0.053-0.008-0.08 c-0.003-0.136-0.006-0.263-0.009-0.329c0.79-0.57,1.475-1.281,2.017-2.091c-0.725,0.322-1.503,0.538-2.32,0.636 C20.514,6.135,21.699,4.943,22,3.999z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://t.me/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (Footer_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 50 50",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M46.137,6.552c-0.75-0.636-1.928-0.727-3.146-0.238l-0.002,0C41.708,6.828,6.728,21.832,5.304,22.445 c-0.259,0.09-2.521,0.934-2.288,2.814c0.208,1.695,2.026,2.397,2.248,2.478l8.893,3.045c0.59,1.964,2.765,9.21,3.246,10.758 c0.3,0.965,0.789,2.233,1.646,2.494c0.752,0.29,1.5,0.025,1.984-0.355l5.437-5.043l8.777,6.845l0.209,0.125 c0.596,0.264,1.167,0.396,1.712,0.396c0.421,0,0.825-0.079,1.211-0.237c1.315-0.54,1.841-1.793,1.896-1.935l6.556-34.077 C47.231,7.933,46.675,7.007,46.137,6.552z M22,32l-3,8l-3-10l23-17L22,32z"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Footer_module_default()).footer__details__wrapper,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Footer_module_default()).details__text__container,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: "The LaSallian"
                        }),
                        " is the official student publication of De La Salle University. It is of the students, by the students, and for the students. Our student writers, photographers, videographers, artists, and web managers are committed to the ",
                        tlsEra,
                        "-year tradition of journalistic excellence and issue-oriented critical thinking.",
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        "502-A Bro. Connon Hall, De La Salle University, 2401 Taft Avenue",
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        "Manila, Philippines"
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).ender__details__wrapper,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: "Powered by Depresso"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onClick: goToTheTop,
                        className: (Footer_module_default()).ender__toTheTop__link,
                        children: "To the top"
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./pages/presents/[articleSlug].js







function ArticlePage({ article , section  }) {
    const router = (0,router_.useRouter)();
    const headline = (0,dehtml/* default */.Z)(article.title["rendered"]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: headline
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                        article: article,
                        section: section
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Body, {
                        article: article,
                        section: section
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FooterFull, {})
                ]
            })
        ]
    });
}
async function getServerSideProps({ params  }) {
    const articleResponse = await fetch(`https://thelasallian.com/wp-json/wp/v2/posts?slug=${params.articleSlug}`);
    const articleData = await articleResponse.json();
    const article = articleData[0];
    const section = ()=>{
        if (article.categories.includes(4)) return "University";
        else if (article.categories.includes(8)) return "Menagerie";
        else if (article.categories.includes(6)) return "Sports";
        else if (article.categories.includes(1883)) return "Vanguard";
        else if (article.categories.includes(5)) return "Opinion";
        else return "None";
    };
    return {
        props: {
            article: article,
            section: section()
        }
    };
}


/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219], () => (__webpack_exec__(7068)));
module.exports = __webpack_exports__;

})();