exports.id = 219;
exports.ids = [219];
exports.modules = {

/***/ 3393:
/***/ ((module) => {

// Exports
module.exports = {
	"card__wrapper__full": "ArticleCard_card__wrapper__full__dhyeP",
	"article__image__link": "ArticleCard_article__image__link__rS8ln",
	"article__image__wrapper": "ArticleCard_article__image__wrapper__lI6Ro",
	"article__image__img": "ArticleCard_article__image__img__qnB1s",
	"is__left": "ArticleCard_is__left__Irma4",
	"is__right": "ArticleCard_is__right__02R68",
	"is__top": "ArticleCard_is__top__wmj0v",
	"is__bottom": "ArticleCard_is__bottom__Ca82v",
	"article__information__wrapper": "ArticleCard_article__information__wrapper__k1qRp",
	"article__headline__wrapper": "ArticleCard_article__headline__wrapper__2pOxu",
	"article__headline__link": "ArticleCard_article__headline__link__Vyecd",
	"article__author__wrapper": "ArticleCard_article__author__wrapper__3dHmL",
	"article__snippet__wrapper": "ArticleCard_article__snippet__wrapper__zdfMT",
	"is__center": "ArticleCard_is__center__gEP_J",
	"is__justified": "ArticleCard_is__justified__D4BWc",
	"is__primary": "ArticleCard_is__primary__Tex5M",
	"is__secondary": "ArticleCard_is__secondary__g8c3C",
	"is__tertiary": "ArticleCard_is__tertiary__aDSKL",
	"is__banner": "ArticleCard_is__banner__YKrCc"
};


/***/ }),

/***/ 1319:
/***/ ((module) => {

// Exports
module.exports = {
	"header__wrapper__full": "Header_header__wrapper__full__N_w_d",
	"header__navbar__wrapper": "Header_header__navbar__wrapper__6LZJn",
	"navbar__headline__wrapper": "Header_navbar__headline__wrapper__Ddvtm",
	"headline__span__section": "Header_headline__span__section__aC2sa",
	"navbar__option__wrapper": "Header_navbar__option__wrapper__cB25q",
	"navbar__input__search": "Header_navbar__input__search__HBoz5",
	"navbar__dropdown__wrapper": "Header_navbar__dropdown__wrapper__45H5u",
	"dropdown__options__list": "Header_dropdown__options__list__aomSw",
	"dropdown__option__wrapper": "Header_dropdown__option__wrapper__ZbbKt",
	"button__icon__more": "Header_button__icon__more__udwv8",
	"navbar__button__wrapper": "Header_navbar__button__wrapper__s1fo8",
	"button__icon__search": "Header_button__icon__search__KxHxc",
	"navbar__logo__wrapper": "Header_navbar__logo__wrapper__ta0Yi",
	"logo__image__img": "Header_logo__image__img__7oTKf",
	"logo__image__star": "Header_logo__image__star__dF4hv",
	"has__headline": "Header_has__headline__V7iaz",
	"university": "Header_university__MEq4P",
	"menagerie": "Header_menagerie__rbj78",
	"sports": "Header_sports__We40l",
	"vanguard": "Header_vanguard__d9mkq",
	"opinion": "Header_opinion__t8wZS"
};


/***/ }),

/***/ 5680:
/***/ ((module) => {

// Exports
module.exports = {
	"header__wrapper__full": "Header_header__wrapper__full__0WDmW",
	"header__logo__wrapper": "Header_header__logo__wrapper__uwJCR",
	"logo__image__img": "Header_logo__image__img__AhEV0",
	"header__navbar__wrapper": "Header_header__navbar__wrapper___L2k7",
	"navbar__option__wrapper": "Header_navbar__option__wrapper__ixCyH",
	"navbar__input__search": "Header_navbar__input__search__YRyN6",
	"navbar__dropdown__wrapper": "Header_navbar__dropdown__wrapper__30_9t",
	"dropdown__options__list": "Header_dropdown__options__list__OHMSz",
	"dropdown__option__wrapper": "Header_dropdown__option__wrapper__Cdi8I",
	"button__icon__more": "Header_button__icon__more__orWSc",
	"navbar__button__wrapper": "Header_navbar__button__wrapper__cXgEq",
	"button__icon__search": "Header_button__icon__search__2IdLQ",
	"navbar__logo__wrapper": "Header_navbar__logo__wrapper__xxbe9",
	"logo__image__star": "Header_logo__image__star__fhor5",
	"is__sticky": "Header_is__sticky___AAi_",
	"university": "Header_university__ZyKjN",
	"menagerie": "Header_menagerie__lOPG1",
	"sports": "Header_sports__xnrXH",
	"vanguard": "Header_vanguard__0fod_",
	"opinion": "Header_opinion__muaOP"
};


/***/ }),

/***/ 2454:
/***/ ((module) => {

// Exports
module.exports = {
	"header__wrapper__full": "Header_header__wrapper__full__J6djl",
	"header__setting__wrapper": "Header_header__setting__wrapper__nAkIg",
	"header__logo__wrapper": "Header_header__logo__wrapper__7Pfm0",
	"logo__image__img": "Header_logo__image__img__JFcN9",
	"header__input__search": "Header_header__input__search__re78R",
	"header__search__wrapper": "Header_header__search__wrapper__NKf_Z",
	"header__dropdown__wrapper": "Header_header__dropdown__wrapper___ciMC",
	"dropdown__item__wrapper": "Header_dropdown__item__wrapper___8RZA",
	"dropdown__item__link": "Header_dropdown__item__link__nDzqk",
	"dropdown__item__button": "Header_dropdown__item__button__E1Uh8",
	"dropdown__item__text": "Header_dropdown__item__text__qdRHG",
	"is__hidden": "Header_is__hidden__hYL_P",
	"university": "Header_university__6sMXi",
	"menagerie": "Header_menagerie__7GVfA",
	"sports": "Header_sports__9_HPV",
	"vanguard": "Header_vanguard__zO6hN",
	"opinion": "Header_opinion__N9O8w"
};


/***/ }),

/***/ 5266:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ArticleCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3393);
/* harmony import */ var _styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Functions_createAuthorsList__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1477);
/* harmony import */ var _components_Functions_dehtml__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5054);
/* harmony import */ var _components_Functions_shorten__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3811);
//detailed__full__right





function ArticleCard({ article , textAlignment ="left" , textLocation ="bottom" , hasHeadline =true , hasAuthor =true , hasSnippet =true , hasImage =true , isMobile =false , isBanner =false  }) {
    const wordCount = ()=>{
        if (isMobile) return 30;
        else if (isBanner) return 30;
        else return 20;
    };
    const headline = (0,_components_Functions_dehtml__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(article.title["rendered"]);
    const authorsList = (0,_components_Functions_createAuthorsList__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(article.authors, "link");
    const snippet = (0,_components_Functions_shorten__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)((0,_components_Functions_dehtml__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(article.excerpt["rendered"]), wordCount());
    const setTextAlignment = ()=>{
        if (textAlignment == "left") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__left);
        else if (textAlignment == "right") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__right);
        else if (textAlignment == "center") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__center);
        else if (textAlignment == "justified") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__justified);
        else return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__left);
    };
    const setTextLocation = ()=>{
        if (textLocation == "left") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__left);
        else if (textLocation == "right") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__right);
        else if (textLocation == "bottom") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__bottom);
        else if (textLocation == "top") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__top);
        else return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__bottom);
    };
    const setTextSize = (property)=>{
        if (property === "headline") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__primary);
        if (property === "author" && hasSnippet) return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__tertiary);
        if (property === "author" && isMobile) return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__tertiary);
        if (property === "author" && !hasSnippet) return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__secondary);
        if (property === "snippet") return (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__secondary);
        else return property.is__secondary;
    };
    const setImage = hasImage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
        className: `${(_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__image__link)}`,
        href: `/presents/${article.slug}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `${(_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__image__wrapper)} ${setTextLocation()}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__image__img),
                src: article.jetpack_featured_media_url
            })
        })
    }) : null;
    const setHeadline = hasHeadline ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${(_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__headline__wrapper)} ${setTextSize("headline")}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            className: (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__headline__link),
            href: `/presents/${article.slug}`,
            children: headline
        })
    }) : null;
    const setAuthor = hasAuthor ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__author__wrapper)} ${setTextSize("author")}`,
        children: [
            "by ",
            authorsList
        ]
    }) : null;
    const setSnippet = hasSnippet ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__snippet__wrapper)} ${setTextSize("snippet")}`,
        children: [
            snippet,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: `/presents/${article.slug}`,
                children: "Read More"
            })
        ]
    }) : null;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().card__wrapper__full)} ${setTextLocation()} ${isBanner ? (_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__banner) : null}`,
        children: [
            setImage,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_styles_ArticleCards_card_out_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__information__wrapper)} ${setTextAlignment()}`,
                children: [
                    setHeadline,
                    setAuthor,
                    setSnippet
                ]
            })
        ]
    });
}


/***/ }),

/***/ 1477:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ createAuthorsList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function createAuthorsList(authors, options = "none") {
    if (options === "link") {
        return createAuthorListWithLink(authors);
    } else {
        return createAuthorListWithNoLink(authors);
    }
}
function createAuthorListWithNoLink(authors) {
    let concatonatedAuthors = [];
    for(let i = 0; i < authors.length; i++){
        if (authors.length > 2) {
            if (i < authors.length - 1) {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: `${authors[i].display_name}, `
                }, `${authors[i].display_name}-comma`));
            } else {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: `and ${authors[i].display_name}`
                }, `${authors[i].display_name}-and`));
            }
        } else if (authors.length == 2) {
            if (i == 0) {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: `${authors[i].display_name}`
                }, `${authors[i].display_name}-comma`));
            } else {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: ` and ${authors[i].display_name}`
                }, `${authors[i].display_name}-comma`));
            }
        } else {
            concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: authors[i].display_name
            }, `${authors[i].display_name}-comma`));
        }
    }
    return concatonatedAuthors;
}
function createAuthorListWithLink(authors) {
    let concatonatedAuthors = [];
    if (authors === null) return;
    for(let i = 0; i < authors.length; i++){
        if (authors.length > 2) {
            if (i < authors.length - 1) {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `/by/${authors[i].slug}`,
                    children: authors[i].display_name
                }, `${authors[i].display_name}-link`));
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: ", "
                }, `${authors[i].display_name}-comma`));
            } else {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: "and "
                }, `${authors[i].display_name}-and`));
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `/by/${authors[i].slug}`,
                    children: authors[i].display_name
                }, `${authors[i].display_name}-link`));
            }
        } else if (authors.length == 2) {
            if (i == 0) {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `/by/${authors[i].slug}`,
                    children: authors[i].display_name
                }, `${authors[i].display_name}-link`));
            } else {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: " and "
                }, `${authors[i].display_name}-and`));
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `/by/${authors[i].slug}`,
                    children: authors[i].display_name
                }, `${authors[i].display_name}-link`));
            }
        } else {
            concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: `/by/${authors[i].slug}`,
                children: authors[i].display_name
            }, `${authors[i].display_name}-link`));
        }
    }
    return concatonatedAuthors;
}


/***/ }),

/***/ 5054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ dehtml)
/* harmony export */ });
function dehtml(string) {
    string = string.replace(/<\/?[^>]+(>|$)/g, "").replaceAll("&#8217;", "’") // apostrophe
    .replaceAll("&#39;", "'") // right apostrophe to apostrophe
    .replaceAll("&#8212;", "—") // different dash to em dash
    .replaceAll("&#8211;", "—") // different dash to em dash
    .replaceAll("&#8208;", "-") // normal dash 
    .replaceAll("&#8230;", "...") // ellipsis
    .replaceAll("&hellip;", "...") //elipsis
    .replaceAll("&#8216;", "‘") // left apostrophe
    .replaceAll("&nbsp;", " "); // non breaking space
    return string;
}


/***/ }),

/***/ 3811:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ shorten)
/* harmony export */ });
function shorten(string, wordLimit = null) {
    if (wordLimit === null) {
        if (string.includes("...")) {
            string = string.substring(0, string.length - 4) + "...";
        } else {
            string = string.substring(0, string.length - 2) + "...";
        }
        return string;
    }
    const wordCount = string.split(" ").length;
    if (wordLimit < wordCount) {
        string = string.split(" ", wordLimit).join(" ");
        if (string[string.length - 1] === "," || string[string.length - 1] === "—" || string[string.length - 1] === ";" || string[string.length - 1] === ".") {
            string = string.substring(0, string.length - 1);
        }
    } else {
        string = string.substring(0, string.length - 2);
    }
    string = string + "...";
    return string;
}


/***/ }),

/***/ 5613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ HeaderV2_Header_Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./styles/HeaderV2/Full/Header.module.scss
var Header_module = __webpack_require__(5680);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
;// CONCATENATED MODULE: ./components/HeaderV2/Full/Header.js



function Header({ article , section ="None"  }) {
    const [searchIsClicked, setSearchIsClicked] = (0,external_react_.useState)(false);
    const [navbarIsSticky, setNavbarIsSticky] = (0,external_react_.useState)(false);
    const [isCompact, setIsCompact] = (0,external_react_.useState)(false);
    const compactWindowSize = 1050;
    const clickedSearch = ()=>{
        setSearchIsClicked((prevValue)=>!prevValue);
    };
    const setSearchIcon = searchIsClicked ? /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: (Header_module_default()).button__icon__search,
        xmlns: "http://www.w3.org/2000/svg",
        height: "48",
        viewBox: "0 96 960 960",
        width: "48",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "m249 849-42-42 231-231-231-231 42-42 231 231 231-231 42 42-231 231 231 231-42 42-231-231-231 231Z"
        })
    }) : /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: (Header_module_default()).button__icon__search,
        xmlns: "http://www.w3.org/2000/svg",
        height: "48",
        viewBox: "0 96 960 960",
        width: "48",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
        })
    });
    const setStickyLogo = ()=>{
        if (navbarIsSticky && section === "None") {
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).navbar__logo__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/",
                    children: isCompact ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Header_module_default()).logo__image__star,
                        src: "/media/svg/icon__tls__star.svg"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Header_module_default()).logo__image__img,
                        src: "/media/svg/logo__tls__compact.svg"
                    })
                })
            });
        } else if (navbarIsSticky && section != -"None") {
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).navbar__logo__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/",
                    children: isCompact ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Header_module_default()).logo__image__star,
                        src: "/media/svg/icon__tls__star__white.svg"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Header_module_default()).logo__image__img,
                        src: "/media/svg/logo__tls__compact__white.svg"
                    })
                })
            });
        } else {
            return null;
        }
    };
    const setNavbar = searchIsClicked ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
            className: (Header_module_default()).navbar__input__search
        })
    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            setStickyLogo(),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).navbar__option__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/section/university",
                    children: "University"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).navbar__option__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/section/menagerie",
                    children: "Menagerie"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).navbar__option__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/section/sports",
                    children: "Sports"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).navbar__option__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/section/vanguard",
                    children: "Vanguard"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).navbar__option__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/section/opinion",
                    children: "Opinion"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${(Header_module_default()).navbar__option__wrapper} ${(Header_module_default()).navbar__dropdown__wrapper}`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        href: "",
                        children: [
                            "More",
                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                className: (Header_module_default()).button__icon__more,
                                xmlns: "http://www.w3.org/2000/svg",
                                height: "48",
                                viewBox: "0 96 960 960",
                                width: "48",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M480 697.537 253.847 471.385l32.615-32.615L480 632.924l193.538-193.539L706.153 472 480 697.537Z"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Header_module_default()).dropdown__options__list,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Header_module_default()).dropdown__option__wrapper,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/about-us",
                                    children: "About Us"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Header_module_default()).dropdown__option__wrapper,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/contact-us",
                                    children: "Contact Us"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Header_module_default()).dropdown__option__wrapper,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/web-specials",
                                    children: "Web Specials"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Header_module_default()).dropdown__option__wrapper,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/pop-town",
                                    children: "Pop Town"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Header_module_default()).dropdown__option__wrapper,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/painting-with-lights",
                                    children: "Painting with Lights"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
    const setSectionColor = ()=>{
        if (section === "University") return (Header_module_default()).university;
        else if (section === "Menagerie") return (Header_module_default()).menagerie;
        else if (section === "Sports") return (Header_module_default()).sports;
        else if (section === "Vanguard") return (Header_module_default()).vanguard;
        else if (section === "Opinion") return (Header_module_default()).opinion;
        else return null;
    };
    const logCurrentYValue = ()=>{
        const headerWrapper = document.querySelector("." + (Header_module_default()).header__wrapper__full);
        const navbarWrapper = document.querySelector("." + (Header_module_default()).header__navbar__wrapper);
        if (headerWrapper === null) return;
        const headerWrapperFullHeight = headerWrapper.offsetHeight;
        const navbarWrapperFullHeight = navbarWrapper.offsetHeight;
        const navbarStartingYValue = parseFloat(headerWrapperFullHeight - navbarWrapperFullHeight);
        const currentYValue = window.pageYOffset;
        if (currentYValue > navbarStartingYValue) {
            navbarWrapper.classList.add((Header_module_default()).is__sticky);
            setNavbarIsSticky(true);
        } else {
            navbarWrapper.classList.remove((Header_module_default()).is__sticky);
            setNavbarIsSticky(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", logCurrentYValue);
    }, []);
    const handleWindowResize = ()=>{
        setIsCompact(window.innerWidth < compactWindowSize);
    };
    (0,external_react_.useEffect)(()=>{
        setIsCompact(window.innerWidth < compactWindowSize);
        window.addEventListener("resize", handleWindowResize);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${(Header_module_default()).header__wrapper__full} ${setSectionColor()}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Header_module_default()).header__logo__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Header_module_default()).logo__image__img,
                        src: "/media/svg/logo--tls--full.svg"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${(Header_module_default()).header__navbar__wrapper} ${setSectionColor()}`,
                children: [
                    setNavbar,
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Header_module_default()).navbar__button__wrapper,
                        onClick: clickedSearch,
                        children: setSearchIcon
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./styles/HeaderV2/Article/Header.module.scss
var Article_Header_module = __webpack_require__(1319);
var Article_Header_module_default = /*#__PURE__*/__webpack_require__.n(Article_Header_module);
// EXTERNAL MODULE: ./components/Functions/dehtml.js
var dehtml = __webpack_require__(5054);
;// CONCATENATED MODULE: ./components/HeaderV2/Article/Header.js




function Header_Header({ article , section ="None"  }) {
    const headline = (0,dehtml/* default */.Z)(article.title["rendered"]);
    const [searchIsClicked, setSearchIsClicked] = (0,external_react_.useState)(false);
    const [isCompact, setIsCompact] = (0,external_react_.useState)(false);
    const [showHeadline, setShowHeadline] = (0,external_react_.useState)(false);
    const compactWindowSize = 1050;
    const headlineYValue = 500;
    const clickedSearch = ()=>{
        setSearchIsClicked((prevValue)=>!prevValue);
    };
    const setSearchIcon = searchIsClicked ? /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: (Article_Header_module_default()).button__icon__search,
        xmlns: "http://www.w3.org/2000/svg",
        height: "48",
        viewBox: "0 96 960 960",
        width: "48",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "m249 849-42-42 231-231-231-231 42-42 231 231 231-231 42 42-231 231 231 231-42 42-231-231-231 231Z"
        })
    }) : /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: (Article_Header_module_default()).button__icon__search,
        xmlns: "http://www.w3.org/2000/svg",
        height: "48",
        viewBox: "0 96 960 960",
        width: "48",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
        })
    });
    const setLogo = ()=>{
        if (section === "None") {
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Article_Header_module_default()).navbar__logo__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/",
                    children: isCompact ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Article_Header_module_default()).logo__image__star,
                        src: "/media/svg/icon__tls__star.svg"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Article_Header_module_default()).logo__image__img,
                        src: "/media/svg/logo__tls__compact.svg"
                    })
                })
            });
        } else {
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Article_Header_module_default()).navbar__logo__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: "/",
                    children: isCompact ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Article_Header_module_default()).logo__image__star,
                        src: "/media/svg/icon__tls__star__white.svg"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Article_Header_module_default()).logo__image__img,
                        src: "/media/svg/logo__tls__compact__white.svg"
                    })
                })
            });
        }
    };
    const setNavbar = ()=>{
        if (searchIsClicked) {
            return /*#__PURE__*/ jsx_runtime_.jsx("input", {
                className: (Article_Header_module_default()).navbar__input__search
            });
        } else if (showHeadline) {
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Article_Header_module_default()).navbar__logo__wrapper,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                className: (Article_Header_module_default()).logo__image__star,
                                src: "/media/svg/icon__tls__star__white.svg"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Article_Header_module_default()).navbar__headline__wrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: `/section/${section.toLowerCase()}`,
                                className: (Article_Header_module_default()).headline__span__section,
                                children: section
                            }),
                            ": ",
                            headline
                        ]
                    })
                ]
            });
        } else {
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    setLogo(),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Article_Header_module_default()).navbar__option__wrapper,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "/section/university",
                            children: "University"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Article_Header_module_default()).navbar__option__wrapper,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "/section/menagerie",
                            children: "Menagerie"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Article_Header_module_default()).navbar__option__wrapper,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "/section/sports",
                            children: "Sports"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Article_Header_module_default()).navbar__option__wrapper,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "/section/vanguard",
                            children: "Vanguard"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Article_Header_module_default()).navbar__option__wrapper,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "/section/opinion",
                            children: "Opinion"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(Article_Header_module_default()).navbar__option__wrapper} ${(Article_Header_module_default()).navbar__dropdown__wrapper}`,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "",
                                children: [
                                    "More",
                                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        className: (Article_Header_module_default()).button__icon__more,
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M480 697.537 253.847 471.385l32.615-32.615L480 632.924l193.538-193.539L706.153 472 480 697.537Z"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Article_Header_module_default()).dropdown__options__list,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Article_Header_module_default()).dropdown__option__wrapper,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/about-us",
                                            children: "About Us"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Article_Header_module_default()).dropdown__option__wrapper,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/contact-us",
                                            children: "Contact Us"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Article_Header_module_default()).dropdown__option__wrapper,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/web-specials",
                                            children: "Web Specials"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Article_Header_module_default()).dropdown__option__wrapper,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/pop-town",
                                            children: "Pop Town"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (Article_Header_module_default()).dropdown__option__wrapper,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/painting-with-lights",
                                            children: "Painting with Lights"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            });
        }
    };
    const setSectionColor = ()=>{
        if (section === "University") return (Article_Header_module_default()).university;
        else if (section === "Menagerie") return (Article_Header_module_default()).menagerie;
        else if (section === "Sports") return (Article_Header_module_default()).sports;
        else if (section === "Vanguard") return (Article_Header_module_default()).vanguard;
        else if (section === "Opinion") return (Article_Header_module_default()).opinion;
        else return null;
    };
    const handleWindowResize = ()=>{
        setIsCompact(window.innerWidth < compactWindowSize);
    };
    (0,external_react_.useEffect)(()=>{
        setIsCompact(window.innerWidth < compactWindowSize);
        window.addEventListener("resize", handleWindowResize);
    }, []);
    const logCurrentYValue = ()=>{
        const currentYValue = window.pageYOffset;
        if (currentYValue > headlineYValue) {
            setShowHeadline(true);
        } else {
            setShowHeadline(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", logCurrentYValue);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `${(Article_Header_module_default()).header__wrapper__full} ${setSectionColor()}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `${(Article_Header_module_default()).header__navbar__wrapper} ${setSectionColor()} ${showHeadline ? (Article_Header_module_default()).has__headline : null}`,
            children: [
                setNavbar(),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (Article_Header_module_default()).navbar__button__wrapper,
                    onClick: clickedSearch,
                    children: setSearchIcon
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./styles/HeaderV2/Mobile/Header.module.scss
var Mobile_Header_module = __webpack_require__(2454);
var Mobile_Header_module_default = /*#__PURE__*/__webpack_require__.n(Mobile_Header_module);
;// CONCATENATED MODULE: ./components/HeaderV2/Mobile/Header.js



function Mobile_Header_Header({ article , section ="None"  }) {
    const [settingsIsClicked, setSettingsIsClicked] = (0,external_react_.useState)(false);
    const [searchIsClicked, setSearchIsClicked] = (0,external_react_.useState)(false);
    const handleSettingsOnClick = ()=>{
        setSettingsIsClicked((prevState)=>!prevState);
        setSearchIsClicked(false);
    };
    const handleSearchOnClick = ()=>{
        setSearchIsClicked((prevState)=>!prevState);
        setSettingsIsClicked(false);
    };
    const setLogo = searchIsClicked ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
        className: (Mobile_Header_module_default()).header__input__search,
        type: "text"
    }) : /*#__PURE__*/ jsx_runtime_.jsx("a", {
        href: "/",
        children: section === "None" ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
            className: (Mobile_Header_module_default()).logo__image__img,
            src: "/media/svg/logo__tls__compact.svg"
        }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
            className: (Mobile_Header_module_default()).logo__image__img,
            src: "/media/svg/logo__tls__compact__white.svg"
        })
    });
    const setSearchIcon = searchIsClicked ? /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: (Mobile_Header_module_default()).button__icon__search,
        onClick: handleSearchOnClick,
        xmlns: "http://www.w3.org/2000/svg",
        height: "48",
        viewBox: "0 96 960 960",
        width: "48",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "m249 849-42-42 231-231-231-231 42-42 231 231 231-231 42 42-231 231 231 231-42 42-231-231-231 231Z"
        })
    }) : /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: (Mobile_Header_module_default()).button__icon__search,
        onClick: handleSearchOnClick,
        xmlns: "http://www.w3.org/2000/svg",
        height: "48",
        viewBox: "0 96 960 960",
        width: "48",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
        })
    });
    (0,external_react_.useEffect)(()=>{
        const dropdownWrapper = document.querySelector("." + (Mobile_Header_module_default()).header__dropdown__wrapper);
        if (settingsIsClicked) {
            dropdownWrapper.classList.remove((Mobile_Header_module_default()).is__hidden);
        } else {
            dropdownWrapper.classList.add((Mobile_Header_module_default()).is__hidden);
        }
    }, [
        settingsIsClicked
    ]);
    const setSectionColor = ()=>{
        if (section === "University") return (Mobile_Header_module_default()).university;
        else if (section === "Menagerie") return (Mobile_Header_module_default()).menagerie;
        else if (section === "Sports") return (Mobile_Header_module_default()).sports;
        else if (section === "Vanguard") return (Mobile_Header_module_default()).vanguard;
        else if (section === "Opinion") return (Mobile_Header_module_default()).opinion;
        else return null;
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${(Mobile_Header_module_default()).header__wrapper__full} ${setSectionColor()}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Mobile_Header_module_default()).header__setting__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (Mobile_Header_module_default()).navbar__button__wrapper,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        className: (Mobile_Header_module_default()).button__icon__setting,
                        onClick: handleSettingsOnClick,
                        xmlns: "http://www.w3.org/2000/svg",
                        height: "48",
                        viewBox: "0 96 960 960",
                        width: "48",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M110.391 831.827v-79.218h739.218v79.218H110.391Zm0-216.218v-79.218h739.218v79.218H110.391Zm0-216.218v-79.783h739.218v79.783H110.391Z"
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Mobile_Header_module_default()).header__logo__wrapper,
                children: setLogo
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Mobile_Header_module_default()).header__search__wrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (Mobile_Header_module_default()).navbar__button__wrapper,
                    children: setSearchIcon
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${(Mobile_Header_module_default()).header__dropdown__wrapper} ${(Mobile_Header_module_default()).is__hidden}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/section/university",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "University"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/section/menagerie",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "Menagerie"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/section/sports",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "Sports"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/section/vanguard",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "Vanguard"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/section/opinion",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "Opinion"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/about-us",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "About Us"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/contact-us",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "Contact Us"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/web-specials",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "Web Specials"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/pop-town",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "Pop Town"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Mobile_Header_module_default()).dropdown__item__wrapper,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: (Mobile_Header_module_default()).dropdown__item__link,
                            href: "/painting-with-lights",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__button,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        height: "48",
                                        viewBox: "0 96 960 960",
                                        width: "48",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Mobile_Header_module_default()).dropdown__item__text,
                                    children: "Painting with Lights"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/HeaderV2/Header.js





function HeaderV2_Header_Header({ article , section ="None"  }) {
    const [isMobile, setIsMobile] = (0,external_react_.useState)(false);
    const handlingWindowResize = ()=>{
        setIsMobile(window.innerWidth < 750);
    };
    (0,external_react_.useEffect)(()=>{
        setIsMobile(window.innerWidth < 750);
        window.addEventListener("resize", handlingWindowResize);
    }, []);
    const setHeader = ()=>{
        if (isMobile) {
            return /*#__PURE__*/ jsx_runtime_.jsx(Mobile_Header_Header, {
                article: article,
                section: section
            });
        }
        if (section !== "None") {
            return /*#__PURE__*/ jsx_runtime_.jsx(Header_Header, {
                article: article,
                section: section
            });
        }
        return /*#__PURE__*/ jsx_runtime_.jsx(Header, {
            article: article,
            section: section
        });
    };
    return setHeader();
}


/***/ })

};
;