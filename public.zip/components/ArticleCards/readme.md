## Article component types

<!--  
    // block--entitiy--modifier

    // banner--card--large

    // article--compact

    // article--detailed--right
    // article--detailed--left
    // article--detailed--down
-->

### names definition
1. detailed ==> info outside of card
1. compact ==> info inside of card

### cards list
1. article--detailed--right
1. article--detailed--left
1. article--detailed--down

1. article--detailed-no-author--left
1. article--detailed-no-author--right
1. article--detailed-no-author--down

1. article--detailed-no-excerpt--left
1. article--detailed-no-excerpt--right
1. article--detailed-no-excerpt--down

1. article--compact--left
1. article--compact--right
1. article--compact--down

1. article--mobile--text
1. article--mobile--no-text



