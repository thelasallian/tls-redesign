import { useRouter } from "next/router";

export default function AuthorPage() {
    return (
        <h1>Details about an author</h1>
    );
}