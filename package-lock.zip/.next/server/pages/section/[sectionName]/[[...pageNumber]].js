(() => {
var exports = {};
exports.id = 760;
exports.ids = [760];
exports.modules = {

/***/ 5229:
/***/ ((module) => {

// Exports
module.exports = {
	"body__wrapper__full": "Body_body__wrapper__full__i5SqC",
	"body__articles__wrapper": "Body_body__articles__wrapper__49fNx",
	"article__card__wrapper": "Body_article__card__wrapper__folpy"
};


/***/ }),

/***/ 2400:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SectionPage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/HeaderV2/Header.js + 3 modules
var Header = __webpack_require__(5613);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./styles/Body/section/Body.module.scss
var Body_module = __webpack_require__(5229);
var Body_module_default = /*#__PURE__*/__webpack_require__.n(Body_module);
// EXTERNAL MODULE: ./components/ArticleCards/card__out/ArticleCard.js
var ArticleCard = __webpack_require__(5266);
;// CONCATENATED MODULE: ./components/Body/section/Body.js




function Body({ articles  }) {
    const [isGettingArticles, setIsGettingArticles] = (0,external_react_.useState)(false);
    const logCurrentYValue = ()=>{
    // const bodyWrapper = document.querySelector("."+styles.body__wrapper__full);
    // const bodyWrapperHeight = bodyWrapper.offsetHeight;
    // if(window.pageYOffset > bodyWrapperHeight) {
    //     console.log("reached max");
    // }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", logCurrentYValue);
    }, []);
    const articleCards = articles.map((article)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (Body_module_default()).article__card__wrapper,
            children: /*#__PURE__*/ jsx_runtime_.jsx(ArticleCard/* default */.Z, {
                article: article,
                textLocation: "right",
                isBanner: false,
                cardSize: "medium",
                hasDate: true
            })
        }, `article__card__wrapper-${article.id}`));
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Body_module_default()).body__wrapper__full,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (Body_module_default()).body__articles__wrapper,
            children: articleCards
        })
    });
}

// EXTERNAL MODULE: ./components/Footer/Full/Footer.js
var Footer = __webpack_require__(7829);
;// CONCATENATED MODULE: ./pages/section/[sectionName]/[[...pageNumber]].js






function SectionPage({ sectionName , articles  }) {
    const sectionNameCapitalized = sectionName.charAt(0).toUpperCase() + sectionName.slice(1);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: sectionNameCapitalized
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                        section: sectionNameCapitalized
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Body, {
                        articles: articles
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
                ]
            })
        ]
    });
}
function sectionToCategory(sectionName) {
    if (sectionName === "university") return 4;
    else if (sectionName === "menagerie") return 8;
    else if (sectionName === "sports") return 6;
    else if (sectionName === "vanguard") return 1883;
    else if (sectionName === "opinion") return 5;
    else null;
}
async function getServerSideProps({ req , res , params  }) {
    const sectionName = params.sectionName;
    const pageNumber = isNaN(params.pageNumber) ? 1 : params.pageNumber;
    const category = sectionToCategory(sectionName);
    res.setHeader("Cache-Control", "public, s-maxage=1, stale-while-revalidate=59");
    const universityResponse = await fetch(`https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=20&categories=${category}&page=${pageNumber}`);
    const universityArticles = await universityResponse.json();
    return {
        props: {
            sectionName: sectionName,
            articles: universityArticles
        }
    };
}


/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [903], () => (__webpack_exec__(2400)));
module.exports = __webpack_exports__;

})();