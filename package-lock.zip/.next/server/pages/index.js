(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 302:
/***/ ((module) => {

// Exports
module.exports = {
	"article__wrapper__banner": "BannerArticleFull_article__wrapper__banner__NZ_F3",
	"article__image__wrapper": "BannerArticleFull_article__image__wrapper__2iF2m",
	"article__image__img": "BannerArticleFull_article__image__img__NzKoz",
	"article__information__wrapper": "BannerArticleFull_article__information__wrapper__ioS59",
	"article__headline__wrapper": "BannerArticleFull_article__headline__wrapper__E_kGP",
	"article__author__wrapper": "BannerArticleFull_article__author__wrapper__Cu3xc",
	"article__snippet__wrapper": "BannerArticleFull_article__snippet__wrapper__Bewl6",
	"snippet__readMore__link": "BannerArticleFull_snippet__readMore__link__eqdWO"
};


/***/ }),

/***/ 864:
/***/ ((module) => {

// Exports
module.exports = {
	"article__link__banner": "BannerArticleMobile_article__link__banner__loK_c",
	"article__image__banner": "BannerArticleMobile_article__image__banner__PUIER",
	"article__image__img": "BannerArticleMobile_article__image__img__LLJzG",
	"article__information__wrapper": "BannerArticleMobile_article__information__wrapper__JEH7T",
	"article__headline__wrapper": "BannerArticleMobile_article__headline__wrapper__vC9Ud",
	"article__author__wrapper": "BannerArticleMobile_article__author__wrapper__RhCKe",
	"article__snippet__wrapper": "BannerArticleMobile_article__snippet__wrapper__hHyog"
};


/***/ }),

/***/ 622:
/***/ ((module) => {

// Exports
module.exports = {
	"body__wrapper__full": "Body_body__wrapper__full__kYUZZ",
	"section__banners__full": "Body_section__banners__full__tUXrb",
	"section__articles__full": "Body_section__articles__full__e7ekK"
};


/***/ }),

/***/ 848:
/***/ ((module) => {

// Exports
module.exports = {
	"footer__wrapper__full": "Footer_footer__wrapper__full__f2HxY",
	"socials__wrapper__list": "Footer_socials__wrapper__list__NGyaq",
	"socials__icon__facebook": "Footer_socials__icon__facebook__o6g6a",
	"socials__icon__svg": "Footer_socials__icon__svg__u37ml",
	"footer__details__wrapper": "Footer_footer__details__wrapper__30I5Q",
	"details__text__container": "Footer_details__text__container__JtWA3",
	"ender__details__wrapper": "Footer_ender__details__wrapper__gt_KH",
	"ender__toTheTop__link": "Footer_ender__toTheTop__link__GEYWH"
};


/***/ }),

/***/ 559:
/***/ ((module) => {

// Exports
module.exports = {
	"header__wrapper__full": "HeaderFull_header__wrapper__full__0xT6J",
	"logo__div__full": "HeaderFull_logo__div__full__MHPip",
	"logo__link__full": "HeaderFull_logo__link__full__znQ07",
	"logo__image__full": "HeaderFull_logo__image__full__RV2D7",
	"header__navbar__full": "HeaderFull_header__navbar__full__MG_ia",
	"navbar__button__section": "HeaderFull_navbar__button__section__dkiwP",
	"navbar__link__section": "HeaderFull_navbar__link__section__jw_Zb",
	"more__button__container": "HeaderFull_more__button__container__hJrM7",
	"more__link__container": "HeaderFull_more__link__container__tH4TB",
	"more__dropdown__icon": "HeaderFull_more__dropdown__icon__Ql_N1",
	"more__list__container": "HeaderFull_more__list__container__TS0cO",
	"more__div__container": "HeaderFull_more__div__container__Zm6mt",
	"more__link__option": "HeaderFull_more__link__option__xm71J",
	"logo__link__visible": "HeaderFull_logo__link__visible__02S9k",
	"logo__image__compact": "HeaderFull_logo__image__compact__PhlR5",
	"logo__image__star": "HeaderFull_logo__image__star__BmMwi",
	"navbar__text__search": "HeaderFull_navbar__text__search__DBxzP",
	"navbar__button__search": "HeaderFull_navbar__button__search__bl_jU",
	"button__search__icon": "HeaderFull_button__search__icon__R1Fbn",
	"sticky": "HeaderFull_sticky__IYOJy",
	"sticky__for__more__options": "HeaderFull_sticky__for__more__options__UIFAK"
};


/***/ }),

/***/ 287:
/***/ ((module) => {

// Exports
module.exports = {
	"header__wrapper__holder": "HeaderMobile_header__wrapper__holder__tRNtp",
	"header__wrapper__mobile": "HeaderMobile_header__wrapper__mobile__dcBWN",
	"logo__div__mobile": "HeaderMobile_logo__div__mobile__6kp1n",
	"logo__link__mobile": "HeaderMobile_logo__link__mobile__0a_ac",
	"logo__image__mobile": "HeaderMobile_logo__image__mobile__fJerl",
	"navbar__text__search": "HeaderMobile_navbar__text__search__eydbU",
	"navbar__button__search": "HeaderMobile_navbar__button__search__U0PFu",
	"navbar__image__search": "HeaderMobile_navbar__image__search__f8P2_",
	"navbar__button__setting": "HeaderMobile_navbar__button__setting__zqtGj",
	"navbar__image__setting": "HeaderMobile_navbar__image__setting__4ou1k",
	"settings__menu__mobile": "HeaderMobile_settings__menu__mobile__wGD63",
	"settings__choices__link": "HeaderMobile_settings__choices__link__JxvsA",
	"settings__menu__choice": "HeaderMobile_settings__menu__choice__sT0yz",
	"settings__menu__choices": "HeaderMobile_settings__menu__choices__RlPwr",
	"settings__image__icon": "HeaderMobile_settings__image__icon__mN3_V"
};


/***/ }),

/***/ 224:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BannerArticleFull)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(302);
/* harmony import */ var _styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Functions_createAuthorsList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(477);
/* harmony import */ var _Functions_cleanArticleExcerpt__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(444);





function BannerArticleFull({ article  }) {
    const headline = article.title["rendered"].replace(/<\/?[^>]+(>|$)/g, ""); // Solution by https://stackoverflow.com/questions/5002111/how-to-strip-html-tags-from-string-in-javascript
    const authors = (0,_Functions_createAuthorsList__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(article.authors);
    const excerpt = (0,_Functions_cleanArticleExcerpt__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(article.excerpt["rendered"]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
        className: (_styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__wrapper__banner),
        href: `/presents/${article.slug}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__image__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: (_styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__image__img),
                    src: article.jetpack_featured_media_url
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__information__wrapper),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__headline__wrapper),
                        children: headline
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__author__wrapper),
                        children: [
                            "by ",
                            authors
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__snippet__wrapper),
                        children: [
                            excerpt,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_styles_BannerArticle_BannerArticleFull_module_scss__WEBPACK_IMPORTED_MODULE_4___default().snippet__readMore__link),
                                children: "Read More"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 427:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ BannerArticleFull)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: ./styles/BannerArticle/BannerArticleMobile.module.scss
var BannerArticleMobile_module = __webpack_require__(864);
var BannerArticleMobile_module_default = /*#__PURE__*/__webpack_require__.n(BannerArticleMobile_module);
// EXTERNAL MODULE: ./components/Functions/createAuthorsList.js
var createAuthorsList = __webpack_require__(477);
// EXTERNAL MODULE: ./components/Functions/cleanArticleExcerpt.js
var cleanArticleExcerpt = __webpack_require__(444);
;// CONCATENATED MODULE: ./components/Functions/getNthWord.js
// Reference: https://stackoverflow.com/questions/14480345/how-to-get-the-nth-occurrence-in-a-string
function getNthWord(sentence, nthIndex = 0) {
    let indexOfNthWord = sentence.split(" ", nthIndex).join(" ").length;
    if (indexOfNthWord === sentence.length) {
        return sentence;
    } else {
        return sentence.substring(0, indexOfNthWord) + "...";
    }
}

;// CONCATENATED MODULE: ./components/ArticleCards/BannerArticleMobile.js






function BannerArticleFull({ article: article1  }) {
    let headline1 = article1.title["rendered"].replace(/<\/?[^>]+(>|$)/g, ""); // Solution by https://stackoverflow.com/questions/5002111/how-to-strip-html-tags-from-string-in-javascript
    const authors1 = (0,createAuthorsList/* default */.Z)(article1.authors);
    let excerpt1 = (0,cleanArticleExcerpt/* default */.Z)(article1.excerpt["rendered"]);
    excerpt1 = getNthWord(excerpt1, 15);
    // headline = getNthWord(headline, 10);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
        className: (BannerArticleMobile_module_default()).article__link__banner,
        href: `/presents/${article1.slug}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (BannerArticleMobile_module_default()).article__image__banner,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: (BannerArticleMobile_module_default()).article__image__img,
                    src: article1.jetpack_featured_media_url
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (BannerArticleMobile_module_default()).article__information__wrapper,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (BannerArticleMobile_module_default()).article__headline__wrapper,
                        children: headline1
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (BannerArticleMobile_module_default()).article__author__wrapper,
                        children: [
                            "by ",
                            authors1
                        ]
                    })
                ]
            })
        ]
    });
}
// deprecated
function BannerArticleWithExcerpt() {
    return /*#__PURE__*/ _jsxs("a", {
        className: styles.article__link__banner,
        href: `/presents/${article.slug}`,
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: styles.article__image__banner,
                children: /*#__PURE__*/ _jsx("img", {
                    className: styles.article__image__img,
                    src: article.jetpack_featured_media_url
                })
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: styles.article__information__wrapper,
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: styles.article__headline__wrapper,
                        children: headline
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: styles.article__author__wrapper,
                        children: [
                            "by ",
                            authors
                        ]
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: styles.article__snippet__wrapper,
                        children: [
                            excerpt,
                            /*#__PURE__*/ _jsx("span", {
                                className: styles.snippet__readMore__link,
                                children: "Read More"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 707:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BodyFull)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(622);
/* harmony import */ var _styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_ArticleCards_BannerArticleFull__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(224);
/* harmony import */ var _components_ArticleCards_BannerArticleMobile__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(427);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(15);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(877);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_4__, swiper__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// Swiper library





function BodyFull({ sections  }) {
    const [windowWidth, setWindowWidth] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const handlingWindowResize = ()=>{
        setWindowWidth(window.innerWidth);
    };
    const bannerArticles = sections.map((section)=>section.articles[0]);
    const bannerArticleCards = bannerArticles.map((bannerArticle)=>windowWidth < 750 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.SwiperSlide, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_BannerArticleMobile__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                article: bannerArticle
            }, `${bannerArticle.id}-bannerArticleMobile`)
        }, `${bannerArticle.id}-SwiperSlide`) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.SwiperSlide, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_BannerArticleFull__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                article: bannerArticle
            }, `${bannerArticle.id}-bannerArticleFull`)
        }, `${bannerArticle.id}-SwiperSlide`));
    //Single-responsibility useEffects
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setWindowWidth(window.innerWidth);
        window.addEventListener("resize", handlingWindowResize);
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_9___default().body__wrapper__full),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_9___default().section__banners__full),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_4__.Swiper, {
                    spaceBetween: 30,
                    loop: true,
                    autoplay: {
                        delay: 5000,
                        disableOnInteraction: false
                    },
                    modules: [
                        swiper__WEBPACK_IMPORTED_MODULE_5__.Autoplay
                    ],
                    className: "mySwiper",
                    children: bannerArticleCards
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_9___default().section__articles__full),
                children: "lorem"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_9___default().section__articles__full),
                children: "lorem"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_9___default().section__articles__full),
                children: "lorem"
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ FooterFull)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/Footer.module.scss
var Footer_module = __webpack_require__(848);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: external "dayjs"
const external_dayjs_namespaceObject = require("dayjs");
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_namespaceObject);
;// CONCATENATED MODULE: ./components/Footer/Footer.js



function FooterFull() {
    const goToTheTop = ()=>{
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    const tlsCreationDate = external_dayjs_default()("1960-10-24");
    const currentDate = external_dayjs_default()();
    const tlsEra = currentDate.diff(tlsCreationDate, "year");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Footer_module_default()).footer__wrapper__full,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).socials__wrapper__list,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://facebook.com/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (Footer_module_default()).socials__icon__facebook,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M17.525,9H14V7c0-1.032,0.084-1.682,1.563-1.682h1.868v-3.18C16.522,2.044,15.608,1.998,14.693,2 C11.98,2,10,3.657,10,6.699V9H7v4l3-0.001V22h4v-9.003l3.066-0.001L17.525,9z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://instagram.com/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (Footer_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M 8 3 C 5.239 3 3 5.239 3 8 L 3 16 C 3 18.761 5.239 21 8 21 L 16 21 C 18.761 21 21 18.761 21 16 L 21 8 C 21 5.239 18.761 3 16 3 L 8 3 z M 18 5 C 18.552 5 19 5.448 19 6 C 19 6.552 18.552 7 18 7 C 17.448 7 17 6.552 17 6 C 17 5.448 17.448 5 18 5 z M 12 7 C 14.761 7 17 9.239 17 12 C 17 14.761 14.761 17 12 17 C 9.239 17 7 14.761 7 12 C 7 9.239 9.239 7 12 7 z M 12 9 A 3 3 0 0 0 9 12 A 3 3 0 0 0 12 15 A 3 3 0 0 0 15 12 A 3 3 0 0 0 12 9 z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://twitter.com/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (Footer_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M22,3.999c-0.78,0.463-2.345,1.094-3.265,1.276c-0.027,0.007-0.049,0.016-0.075,0.023c-0.813-0.802-1.927-1.299-3.16-1.299 c-2.485,0-4.5,2.015-4.5,4.5c0,0.131-0.011,0.372,0,0.5c-3.353,0-5.905-1.756-7.735-4c-0.199,0.5-0.286,1.29-0.286,2.032 c0,1.401,1.095,2.777,2.8,3.63c-0.314,0.081-0.66,0.139-1.02,0.139c-0.581,0-1.196-0.153-1.759-0.617c0,0.017,0,0.033,0,0.051 c0,1.958,2.078,3.291,3.926,3.662c-0.375,0.221-1.131,0.243-1.5,0.243c-0.26,0-1.18-0.119-1.426-0.165 c0.514,1.605,2.368,2.507,4.135,2.539c-1.382,1.084-2.341,1.486-5.171,1.486H2C3.788,19.145,6.065,20,8.347,20 C15.777,20,20,14.337,20,8.999c0-0.086-0.002-0.266-0.005-0.447C19.995,8.534,20,8.517,20,8.499c0-0.027-0.008-0.053-0.008-0.08 c-0.003-0.136-0.006-0.263-0.009-0.329c0.79-0.57,1.475-1.281,2.017-2.091c-0.725,0.322-1.503,0.538-2.32,0.636 C20.514,6.135,21.699,4.943,22,3.999z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://t.me/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (Footer_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 50 50",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M46.137,6.552c-0.75-0.636-1.928-0.727-3.146-0.238l-0.002,0C41.708,6.828,6.728,21.832,5.304,22.445 c-0.259,0.09-2.521,0.934-2.288,2.814c0.208,1.695,2.026,2.397,2.248,2.478l8.893,3.045c0.59,1.964,2.765,9.21,3.246,10.758 c0.3,0.965,0.789,2.233,1.646,2.494c0.752,0.29,1.5,0.025,1.984-0.355l5.437-5.043l8.777,6.845l0.209,0.125 c0.596,0.264,1.167,0.396,1.712,0.396c0.421,0,0.825-0.079,1.211-0.237c1.315-0.54,1.841-1.793,1.896-1.935l6.556-34.077 C47.231,7.933,46.675,7.007,46.137,6.552z M22,32l-3,8l-3-10l23-17L22,32z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "mailto:me@thelasallian.com",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (Footer_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            height: "48",
                            viewBox: "0 96 960 960",
                            width: "48",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M142.152 901.978q-27.599 0-47.865-20.265-20.265-20.266-20.265-47.865V318.152q0-27.697 20.265-48.033 20.266-20.337 47.865-20.337h675.696q27.697 0 48.033 20.337 20.337 20.336 20.337 48.033v515.696q0 27.599-20.337 47.865-20.336 20.265-48.033 20.265H142.152ZM480 601.652l337.848-223v-60.5L480 536.152l-337.848-218v60.5l337.848 223Z"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Footer_module_default()).footer__details__wrapper,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Footer_module_default()).details__text__container,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: "The LaSallian"
                        }),
                        " is the official student publication of De La Salle University. It is of the students, by the students, and for the students. Our student writers, photographers, videographers, artists, and web managers are committed to the ",
                        tlsEra,
                        "-year tradition of journalistic excellence and issue-oriented critical thinking.",
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        "502-A Bro. Connon Hall, De La Salle University, 2401 Taft Avenue",
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        "Manila, Philippines"
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).ender__details__wrapper,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: "Powered by Depresso"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onClick: goToTheTop,
                        className: (Footer_module_default()).ender__toTheTop__link,
                        children: "To the top"
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 444:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ cleanArticleExcerpt)
/* harmony export */ });
function cleanArticleExcerpt(excerpt, shortenTo = -1) {
    excerpt = excerpt.replace(/<[^>]+>/g, "");
    let ellipsisIndex = excerpt.indexOf("&hellip;");
    if (shortenTo != -1) {
        let finalWordIndex = getPositionOfString(excerpt, " ", shortenTo);
        return excerpt.substring(0, finalWordIndex) + "...";
    }
    if (ellipsisIndex == -1) {
        return excerpt.substring(0, excerpt.length - 1) + "..";
    } else {
        return excerpt.substring(0, ellipsisIndex) + "...";
    }
}
// Reference: https://stackoverflow.com/questions/14480345/how-to-get-the-nth-occurrence-in-a-string
function getPositionOfString(entry, targetString, index = 0) {
    return entry.split(targetString, index).join(targetString).length;
}


/***/ }),

/***/ 477:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ createAuthorsList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function createAuthorsList(authors, options = "none") {
    if (options === "none") {
        return createAuthorListWithNoLink(authors);
    } else {
        return createAuthorListWithLink(authors);
    }
}
function createAuthorListWithNoLink(authors) {
    let concatonatedAuthors = [];
    for(let i = 0; i < authors.length; i++){
        if (authors.length > 2) {
            if (i < authors.length - 1) {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: `${authors[i].display_name}, `
                }, `${authors[i].display_name}-comma`));
            } else {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: `and ${authors[i].display_name}`
                }, `${authors[i].display_name}-and`));
            }
        } else if (authors.length == 2) {
            if (i == 0) {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: `${authors[i].display_name}`
                }, `${authors[i].display_name}-comma`));
            } else {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: ` and ${authors[i].display_name}`
                }, `${authors[i].display_name}-comma`));
            }
        } else {
            concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: authors[i].display_name
            }, `${authors[i].display_name}-comma`));
        }
    }
    return concatonatedAuthors;
}
function createAuthorListWithLink(authors) {
    let concatonatedAuthors = [];
    for(let i = 0; i < authors.length; i++){
        if (authors.length > 2) {
            if (i == 0) {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `/by/${authors[i].slug}`,
                    children: authors[i].display_name
                }, `${authors[i].display_name}-link`));
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: ", "
                }, `${authors[i].display_name}-comma`));
            } else {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: "and "
                }, `${authors[i].display_name}-and`));
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `/by/${authors[i].slug}`,
                    children: authors[i].display_name
                }, `${authors[i].display_name}-link`));
            }
        } else if (authors.length == 2) {
            if (i == 0) {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `/by/${authors[i].slug}`,
                    children: authors[i].display_name
                }, `${authors[i].display_name}-link`));
            } else {
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: " and "
                }, `${authors[i].display_name}-and`));
                concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `/by/${authors[i].slug}`,
                    children: authors[i].display_name
                }, `${authors[i].display_name}-link`));
            }
        } else {
            concatonatedAuthors.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: `/by/${authors[i].slug}`,
                children: authors[i].display_name
            }, `${authors[i].display_name}-link`));
        }
    }
    return concatonatedAuthors;
}


/***/ }),

/***/ 498:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: ./styles/HeaderFull.module.scss
var HeaderFull_module = __webpack_require__(559);
var HeaderFull_module_default = /*#__PURE__*/__webpack_require__.n(HeaderFull_module);
;// CONCATENATED MODULE: ./components/Header/HeaderFull.js



function HeaderFull() {
    const [searchIsClicked, setSearchIsClicked] = (0,external_react_.useState)(false);
    const [pageYOffset, setPageYOffset] = (0,external_react_.useState)(0);
    const [isNavbarVisible, setIsNavbarVisible] = (0,external_react_.useState)(false);
    const [windowWidth, setWindowWidth] = (0,external_react_.useState)(0);
    const searchedSomething = (event)=>{
        const searchBar = document.getElementById("navbar__text__search");
        if (searchBar != null) {
            const searchEntry = searchBar.value.trim();
            if (event.key == "Enter" && searchEntry != "") {
                console.log("Searching:", searchEntry);
            } else if (event.key == "Escape") {
                setSearchIsClicked(!searchIsClicked);
            }
        }
    };
    const logPageYOffset = ()=>{
        setPageYOffset(window.pageYOffset);
    };
    const handlingWindowResize = ()=>{
        setWindowWidth(window.innerWidth);
    };
    //Single-responsibility useEffects
    (0,external_react_.useEffect)(()=>{
        if (searchIsClicked) {
            window.addEventListener("keydown", searchedSomething);
        } else {
            window.removeEventListener("keydown", searchedSomething);
        }
    });
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", logPageYOffset);
        const logo = document.getElementById("header__logo__full");
        const navbar = document.getElementById("header__navbar__full");
        const options = document.getElementById("more__list__container");
        setIsNavbarVisible(pageYOffset < logo.offsetHeight);
        if (isNavbarVisible) {
            navbar.classList.remove((HeaderFull_module_default()).sticky);
            if (options != null) options.classList.remove((HeaderFull_module_default()).sticky__for__more__options);
        } else {
            navbar.classList.add((HeaderFull_module_default()).sticky);
            if (options != null) options.classList.add((HeaderFull_module_default()).sticky__for__more__options);
        }
    });
    (0,external_react_.useEffect)(()=>{
        setWindowWidth(window.innerWidth);
        window.addEventListener("resize", handlingWindowResize);
    });
    const changeNavbarToSearchBar = ()=>{
        setSearchIsClicked(!searchIsClicked);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (HeaderFull_module_default()).header__wrapper__full,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (HeaderFull_module_default()).logo__div__full,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    className: (HeaderFull_module_default()).logo__link__full,
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        id: "header__logo__full",
                        className: (HeaderFull_module_default()).logo__image__full,
                        src: "/media/svg/logo--tls--full.svg"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                id: "header__navbar__full",
                className: (HeaderFull_module_default()).header__navbar__full,
                children: searchIsClicked ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "navbar__text__search",
                            className: (HeaderFull_module_default()).navbar__text__search,
                            type: "text"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__search,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                onClick: changeNavbarToSearchBar,
                                className: (HeaderFull_module_default()).button__search__icon,
                                xmlns: "http://www.w3.org/2000/svg",
                                height: "48",
                                viewBox: "0 96 960 960",
                                width: "48",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "m249 849-42-42 231-231-231-231 42-42 231 231 231-231 42 42-231 231 231 231-42 42-231-231-231 231Z"
                                })
                            })
                        })
                    ]
                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        isNavbarVisible ? "" : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (HeaderFull_module_default()).navbar__button__section,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/",
                                    className: (HeaderFull_module_default()).logo__link__visible,
                                    children: windowWidth < 900 ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderFull_module_default()).logo__image__star,
                                        src: "/media/svg/icon--tls--star.svg"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderFull_module_default()).logo__image__compact,
                                        src: "/media/svg/logo--tls--compact.svg"
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/university",
                                children: "University"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/menagerie",
                                children: "Menagerie"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/sports",
                                children: "Sports"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/vanguard",
                                children: "Vanguard"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/opinion",
                                children: "Opinion"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (HeaderFull_module_default()).more__button__container,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: (HeaderFull_module_default()).more__link__container,
                                        href: "/about",
                                        children: [
                                            "More",
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                className: (HeaderFull_module_default()).more__dropdown__icon,
                                                xmlns: "http://www.w3.org/2000/svg",
                                                height: "48",
                                                viewBox: "0 96 960 960",
                                                width: "48",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M480 697.537 253.847 471.385l32.615-32.615L480 632.924l193.538-193.539L706.153 472 480 697.537Z"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    id: "more__list__container",
                                    className: (HeaderFull_module_default()).more__list__container,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (HeaderFull_module_default()).more__div__container,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (HeaderFull_module_default()).more__link__option,
                                                href: "/about",
                                                children: "About"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (HeaderFull_module_default()).more__div__container,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (HeaderFull_module_default()).more__link__option,
                                                href: "/contact-us",
                                                children: "Contact Us"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (HeaderFull_module_default()).more__div__container,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (HeaderFull_module_default()).more__link__option,
                                                href: "/specials/",
                                                children: "Specials"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__search,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                className: (HeaderFull_module_default()).button__search__icon,
                                onClick: changeNavbarToSearchBar,
                                xmlns: "http://www.w3.org/2000/svg",
                                height: "48",
                                viewBox: "0 96 960 960",
                                width: "48",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./styles/HeaderMobile.module.scss
var HeaderMobile_module = __webpack_require__(287);
var HeaderMobile_module_default = /*#__PURE__*/__webpack_require__.n(HeaderMobile_module);
;// CONCATENATED MODULE: ./components/Header/HeaderMobile.js



function HeaderMobile() {
    const [searchIsClicked, setSearchIsClicked] = (0,external_react_.useState)(false);
    const [settingsIsClicked, setSettingsIsClicked] = (0,external_react_.useState)(false);
    const searchedSomething = (event)=>{
        const searchBar = document.getElementById("navbar__text__search");
        if (searchBar != null) {
            const searchEntry = searchBar.value.trim();
            if (event.key == "Enter" && searchEntry != "") {
                console.log("Searching:", searchEntry);
            } else if (event.key == "Escape") {
                setSearchIsClicked(!searchIsClicked);
            }
        }
    };
    //Single-responsibility useEffects
    (0,external_react_.useEffect)(()=>{
        if (searchIsClicked) {
            window.addEventListener("keydown", searchedSomething);
        } else {
            window.removeEventListener("keydown", searchedSomething);
        }
    });
    (0,external_react_.useEffect)(()=>{
        if (settingsIsClicked) {
            setSearchIsClicked(false);
            document.body.style.overflow = "hidden";
        } else if (!settingsIsClicked) {
            document.body.style.overflow = "visible";
        }
    }, [
        settingsIsClicked
    ]);
    (0,external_react_.useEffect)(()=>{
        if (searchIsClicked) setSettingsIsClicked(false);
    }, [
        searchIsClicked
    ]);
    const changeNavbarToSearchBar = ()=>{
        setSearchIsClicked(!searchIsClicked);
    };
    const openSettingsMenu = ()=>{
        setSettingsIsClicked(!settingsIsClicked);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (HeaderMobile_module_default()).logo__div__holder
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (HeaderMobile_module_default()).header__wrapper__mobile,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (HeaderMobile_module_default()).navbar__button__setting,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (HeaderMobile_module_default()).navbar__image__setting,
                            onClick: openSettingsMenu,
                            xmlns: "http://www.w3.org/2000/svg",
                            height: "48",
                            viewBox: "0 96 960 960",
                            width: "48",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M110.391 831.827v-79.218h739.218v79.218H110.391Zm0-216.218v-79.218h739.218v79.218H110.391Zm0-216.218v-79.783h739.218v79.783H110.391Z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (HeaderMobile_module_default()).logo__div__mobile,
                        children: searchIsClicked ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                id: "navbar__text__search",
                                className: (HeaderMobile_module_default()).navbar__text__search,
                                type: "text"
                            })
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: (HeaderMobile_module_default()).logo__link__mobile,
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                id: "header__logo__full",
                                className: (HeaderMobile_module_default()).logo__image__mobile,
                                src: "/media/svg/logo--tls--compact.svg"
                            })
                        })
                    }),
                    searchIsClicked ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (HeaderMobile_module_default()).navbar__button__search,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (HeaderMobile_module_default()).navbar__image__search,
                            onClick: changeNavbarToSearchBar,
                            xmlns: "http://www.w3.org/2000/svg",
                            height: "48",
                            viewBox: "0 96 960 960",
                            width: "48",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M249 862.566 193.434 807l231-231-231-231L249 289.434l231 231 231-231L766.566 345l-231 231 231 231L711 862.566l-231-231-231 231Z"
                            })
                        })
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (HeaderMobile_module_default()).navbar__button__search,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (HeaderMobile_module_default()).navbar__image__search,
                            onClick: changeNavbarToSearchBar,
                            xmlns: "http://www.w3.org/2000/svg",
                            height: "48",
                            viewBox: "0 96 960 960",
                            width: "48",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M795.435 950.827 529.043 685.001q-29.434 24.26-69.111 37.934-39.676 13.674-85.323 13.674-112.119 0-189.864-77.826Q106.999 580.957 106.999 471t77.827-187.783q77.826-77.826 188.283-77.826 110.456 0 187.782 77.826 77.327 77.826 77.327 187.933 0 43.98-13.152 83.133-13.153 39.152-39.457 73.587l267.392 265.391-57.566 57.566ZM373.808 657.391q77.659 0 131.425-54.533Q558.999 548.326 558.999 471q0-77.326-53.849-131.858-53.849-54.533-131.342-54.533-78.326 0-132.958 54.533Q186.218 393.674 186.218 471q0 77.326 54.549 131.858 54.549 54.533 133.041 54.533Z"
                            })
                        })
                    })
                ]
            }),
            settingsIsClicked ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: (HeaderMobile_module_default()).settings__menu__mobile,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/university",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "University"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/menagerie",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Menagerie"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/sports",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Sports"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/vanguard",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Vanguard"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/opinion",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Opinion"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/about",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "About"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/contact-us",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Contact Us"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/specials",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Specials"
                                    })
                                ]
                            })
                        })
                    })
                ]
            }) : ""
        ]
    });
}

;// CONCATENATED MODULE: ./components/Header/Header.js




function Header() {
    const [windowWidth, setWindowWidth] = (0,external_react_.useState)(0);
    const handlingWindowResize = ()=>{
        setWindowWidth(window.innerWidth);
    };
    //Single-responsibility useEffects
    (0,external_react_.useEffect)(()=>{
        setWindowWidth(window.innerWidth);
        window.addEventListener("resize", handlingWindowResize);
    }, []);
    if (windowWidth < 750) {
        return /*#__PURE__*/ jsx_runtime_.jsx(HeaderMobile, {});
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx(HeaderFull, {});
    }
}


/***/ }),

/***/ 616:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Header_Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(498);
/* harmony import */ var _components_Body_index_Body__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(707);
/* harmony import */ var _components_Footer_Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(780);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Body_index_Body__WEBPACK_IMPORTED_MODULE_3__]);
_components_Body_index_Body__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function Home({ sections  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: "The LaSallian — The bastion of issue-oriented critical thinking"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header_Header__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Body_index_Body__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        sections: sections
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer_Footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
}
async function getServerSideProps({ req , res  }) {
    res.setHeader("Cache-Control", "public, s-maxage=10, stale-while-revalidate=59");
    const universityResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=4");
    const universityArticles = await universityResponse.json();
    const menagerieResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=8");
    const menagerieArticles = await menagerieResponse.json();
    const sportsResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=6");
    const sportsArticles = await sportsResponse.json();
    const vanguardResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=1883");
    const vanguardArticles = await vanguardResponse.json();
    const opinionResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=5");
    const opinionArticles = await opinionResponse.json();
    return {
        props: {
            sections: [
                {
                    name: "University",
                    category: 4,
                    articles: universityArticles
                },
                {
                    name: "Menagerie",
                    category: 8,
                    articles: menagerieArticles
                },
                {
                    name: "Sports",
                    category: 6,
                    articles: sportsArticles
                },
                {
                    name: "Vanguard",
                    category: 1883,
                    articles: vanguardArticles
                },
                {
                    name: "Opinions",
                    category: 5,
                    articles: opinionArticles
                }
            ]
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 176:
/***/ (() => {



/***/ }),

/***/ 996:
/***/ (() => {



/***/ }),

/***/ 722:
/***/ (() => {



/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 877:
/***/ ((module) => {

"use strict";
module.exports = import("swiper");;

/***/ }),

/***/ 15:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(616));
module.exports = __webpack_exports__;

})();