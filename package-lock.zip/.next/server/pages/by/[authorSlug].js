(() => {
var exports = {};
exports.id = 675;
exports.ids = [675];
exports.modules = {

/***/ 4219:
/***/ ((module) => {

// Exports
module.exports = {
	"body__wrapper__full": "Body_body__wrapper__full__WSBT0",
	"author__information__wrapper": "Body_author__information__wrapper__vKJM0",
	"author__image__wrapper": "Body_author__image__wrapper__ON2BV",
	"author__details__wrapper": "Body_author__details__wrapper__ReaUP",
	"author__name__wrapper": "Body_author__name__wrapper__1_mEs",
	"author__bio__wrapper": "Body_author__bio__wrapper__EQ3_g",
	"author__articles__wrapper": "Body_author__articles__wrapper__4G3Ga",
	"articles__card__wrapper": "Body_articles__card__wrapper__R9k2g",
	"author__button__wrapper": "Body_author__button__wrapper__vIuex",
	"author__button__item": "Body_author__button__item__4Q2bc"
};


/***/ }),

/***/ 8882:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AuthorPage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/HeaderV2/Header.js + 3 modules
var Header = __webpack_require__(5613);
// EXTERNAL MODULE: ./styles/Body/author/Body.module.scss
var Body_module = __webpack_require__(4219);
var Body_module_default = /*#__PURE__*/__webpack_require__.n(Body_module);
// EXTERNAL MODULE: ./components/ArticleCards/card__out/ArticleCard.js
var ArticleCard = __webpack_require__(5266);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/Body/author/Body.js




function Body({ author , publishPressId , articles  }) {
    const [pageNumber, setPageNumber] = (0,external_react_.useState)(2);
    const [articleData, setArticleData] = (0,external_react_.useState)(articles);
    const [isMobile, setIsMobile] = (0,external_react_.useState)(false);
    const [isFetching, setIsFetching] = (0,external_react_.useState)(false);
    const [hasMoreArticles, setHasMoreArticles] = (0,external_react_.useState)(true);
    const handlingWindowResize = ()=>{
        setIsMobile(window.innerWidth < 750);
    };
    (0,external_react_.useEffect)(()=>{
        setIsMobile(window.innerWidth < 750);
        window.addEventListener("resize", handlingWindowResize);
    }, []);
    const articleCards = articleData.map((article)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (Body_module_default()).articles__card__wrapper,
            children: /*#__PURE__*/ jsx_runtime_.jsx(ArticleCard/* default */.Z, {
                article: article,
                hasSnippet: !isMobile,
                textLocation: "right",
                isBanner: false,
                cardSize: "medium",
                hasDate: true,
                isMobile: isMobile
            })
        }, `articles__card__wrapper-${article.id}`));
    const fetchArticles = async ()=>{
        setIsFetching(true);
        const response = await fetch(`https://thelasallian.com/wp-json/wp/v2/posts?ppma_author=${publishPressId}&page=${pageNumber}&per_page=5&_fields=id,date,authors,excerpt,title,slug,categories,jetpack_featured_media_url`);
        const newData = await response.json();
        if (newData.length === undefined) {
            console.log("No more articles left.");
            setIsFetching(false);
            setHasMoreArticles(false);
            return;
        }
        if (newData.length !== 0) {
            setArticleData((prevState)=>[
                    ...prevState,
                    ...newData
                ]);
            setPageNumber((prevState)=>prevState + 1);
            return;
        }
    };
    (0,external_react_.useEffect)(()=>{
        setIsFetching(false);
    }, [
        articleData
    ]);
    const setLoading = isFetching ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Body_module_default()).body__loading__wrapper,
        children: "Fetching more articles..."
    }) : hasMoreArticles ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
        onClick: fetchArticles,
        className: (Body_module_default()).author__button__item,
        children: "Show More"
    }) : null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Body_module_default()).body__wrapper__full,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Body_module_default()).author__information__wrapper,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Body_module_default()).author__image__wrapper,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            className: (Body_module_default()).author__image__img,
                            src: author.avatar_urls["96"]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Body_module_default()).author__details__wrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Body_module_default()).author__name__wrapper,
                                children: author.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Body_module_default()).author__bio__wrapper,
                                children: author.description != "" ? author.description : "A contributor of The LaSallian. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Body_module_default()).author__articles__wrapper,
                children: articleCards
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Body_module_default()).author__button__wrapper,
                children: setLoading
            })
        ]
    });
}

// EXTERNAL MODULE: ./components/Footer/Full/Footer.js
var Footer = __webpack_require__(7829);
;// CONCATENATED MODULE: ./pages/by/[authorSlug].js






function AuthorPage({ author , publishPressId , articles  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: `${author.name} - The LaSallian`
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                        section: "University"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Body, {
                        author: author,
                        publishPressId: publishPressId,
                        articles: articles
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {
                        section: "University"
                    })
                ]
            })
        ]
    });
}
async function getServerSideProps({ req , res , params  }) {
    const authorSlug = params.authorSlug;
    res.setHeader("Cache-Control", "public, s-maxage=1, stale-while-revalidate=59");
    const authorResponse = await fetch(`https://thelasallian.com/wp-json/wp/v2/users/?slug=${authorSlug}`);
    const authorData = await authorResponse.json();
    const authorId = authorData[0].id;
    const publishPressResponse = await fetch(`https://thelasallian.com/wp-json/wp/v2/posts?author=${authorId}&per_page=1&_fields=id,authors,excerpt,date,title,slug,categories,jetpack_featured_media_url`);
    const publishPressData = await publishPressResponse.json();
    const publishPressId = publishPressData[0].authors[0].term_id;
    const articlesResponse = await fetch(`https://thelasallian.com/wp-json/wp/v2/posts?ppma_author=${publishPressId}&per_page=5&_fields=id,authors,date,excerpt,title,slug,categories,jetpack_featured_media_url`);
    const articlesData = await articlesResponse.json();
    return {
        props: {
            author: authorData[0],
            publishPressId: publishPressId,
            articles: articlesData
        }
    };
}


/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [903], () => (__webpack_exec__(8882)));
module.exports = __webpack_exports__;

})();