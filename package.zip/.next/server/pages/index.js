(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 868:
/***/ ((module) => {

// Exports
module.exports = {
	"card__wrapper__full": "ArticleCard_card__wrapper__full__YRQ_k",
	"article__image__link": "ArticleCard_article__image__link__b_zKL",
	"article__image__wrapper": "ArticleCard_article__image__wrapper__2mvgz",
	"article__image__img": "ArticleCard_article__image__img__k_Gq_",
	"article__information__wrapper": "ArticleCard_article__information__wrapper__VA8nI",
	"article__headline__wrapper": "ArticleCard_article__headline__wrapper__RADY2",
	"article__headline__link": "ArticleCard_article__headline__link__Q3yD0",
	"article__author__wrapper": "ArticleCard_article__author__wrapper__TkgVp",
	"article__snippet__wrapper": "ArticleCard_article__snippet__wrapper__nVhe_",
	"is__right": "ArticleCard_is__right__ABLAy",
	"is__left": "ArticleCard_is__left__R0kV2",
	"is__center": "ArticleCard_is__center__RDJXy",
	"is__justified": "ArticleCard_is__justified__CnX9W",
	"is__primary": "ArticleCard_is__primary__h5nz1",
	"is__secondary": "ArticleCard_is__secondary__VP8C2",
	"is__tertiary": "ArticleCard_is__tertiary__78bfj",
	"is__banner": "ArticleCard_is__banner__SIuUG"
};


/***/ }),

/***/ 9722:
/***/ ((module) => {

// Exports
module.exports = {
	"body__wrapper__full": "Body_body__wrapper__full__kYUZZ",
	"body__section__wrapper": "Body_body__section__wrapper__NDdwj"
};


/***/ }),

/***/ 3389:
/***/ ((module) => {

// Exports
module.exports = {
	"section__wrapper__full": "Section_section__wrapper__full__TiSpm",
	"section__title__wrapper": "Section_section__title__wrapper__VhYCK",
	"section__title__link": "Section_section__title__link__osCBS",
	"university": "Section_university__RfFk1",
	"menagerie": "Section_menagerie__UjGwb",
	"sports": "Section_sports__UxYkg",
	"vanguard": "Section_vanguard__sIEaW",
	"opinion": "Section_opinion____Ji4",
	"section__articles__wrapper": "Section_section__articles__wrapper__CiZYe",
	"articles__left__wrapper": "Section_articles__left__wrapper___Nczo",
	"articles__right__wrapper": "Section_articles__right__wrapper__MWr8p",
	"article__wrapper__full": "Section_article__wrapper__full__FJcIu"
};


/***/ }),

/***/ 9624:
/***/ ((module) => {

// Exports
module.exports = {
	"section__wrapper__full": "Section_section__wrapper__full__hiXKt",
	"section__title__wrapper": "Section_section__title__wrapper__5wXx7",
	"section__title__link": "Section_section__title__link__Y2aNh",
	"university": "Section_university__utmyI",
	"menagerie": "Section_menagerie__yN7l1",
	"sports": "Section_sports__MP_NT",
	"vanguard": "Section_vanguard__5hXs1",
	"opinion": "Section_opinion__gjxpV",
	"section__articles__wrapper": "Section_section__articles__wrapper__y02Jo",
	"articles__left__wrapper": "Section_articles__left__wrapper__97HbW",
	"articles__right__wrapper": "Section_articles__right__wrapper__VjQbA",
	"article__wrapper__full": "Section_article__wrapper__full__f74sj"
};


/***/ }),

/***/ 8393:
/***/ ((module) => {

// Exports
module.exports = {
	"section__wrapper__full": "Section_section__wrapper__full__IYH06",
	"section__title__wrapper": "Section_section__title__wrapper__qZvsW",
	"section__title__link": "Section_section__title__link__4AJv_",
	"university": "Section_university__n6W7S",
	"menagerie": "Section_menagerie___KdCb",
	"sports": "Section_sports__4pdwi",
	"vanguard": "Section_vanguard__cvnRe",
	"opinion": "Section_opinion__VdNe1",
	"section__articles__wrapper": "Section_section__articles__wrapper__rBOsa",
	"articles__left__wrapper": "Section_articles__left__wrapper__6oUDo",
	"article__wrapper__full": "Section_article__wrapper__full__V_5e0",
	"articles__right__wrapper": "Section_articles__right__wrapper__IBgb_"
};


/***/ }),

/***/ 9183:
/***/ ((module) => {

// Exports
module.exports = {
	"section__wrapper__full": "Section_section__wrapper__full__Y6rKm",
	"section__title__wrapper": "Section_section__title__wrapper__BJX0_",
	"section__title__link": "Section_section__title__link__xj4Lh",
	"university": "Section_university__nlTzU",
	"menagerie": "Section_menagerie__8FEMH",
	"sports": "Section_sports__k_Ai5",
	"vanguard": "Section_vanguard__G_siC",
	"opinion": "Section_opinion__MGfS7",
	"section__articles__wrapper": "Section_section__articles__wrapper__B6AEQ",
	"articles__left__wrapper": "Section_articles__left__wrapper__yrIzi",
	"articles__right__wrapper": "Section_articles__right__wrapper__qrzHo"
};


/***/ }),

/***/ 546:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ArticleCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(868);
/* harmony import */ var _styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Functions_dehtml__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5054);
/* harmony import */ var _components_Functions_createAuthorsList__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1477);
/* harmony import */ var _components_Functions_shorten__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3811);
//style__amount of detail__where the text is with respect to image





function ArticleCard({ article , textAlignment ="left" , textLocation ="bottom" , hasHeadline =true , hasAuthor =true , hasSnippet =false , hasImage =true , isMobile =false , isBanner =false  }) {
    const wordCount = ()=>{
        if (isMobile) return null;
        else if (isBanner) return 30;
        else return 20;
    };
    const headline = (0,_components_Functions_dehtml__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(article.title["rendered"]);
    const authorsList = (0,_components_Functions_createAuthorsList__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(article.authors, "link");
    const snippet = (0,_components_Functions_shorten__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)((0,_components_Functions_dehtml__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(article.excerpt["rendered"]), wordCount());
    const setTextAlignment = ()=>{
        if (textAlignment == "left") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__left);
        else if (textAlignment == "right") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__right);
        else if (textAlignment == "center") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__center);
        else if (textAlignment == "justified") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__justified);
        else return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__left);
    };
    const setTextLocation = ()=>{
        if (textLocation == "left") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__left);
        else if (textLocation == "right") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__right);
        else if (textLocation == "bottom") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__bottom);
        else if (textLocation == "top") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__top);
        else return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__bottom);
    };
    const setTextSize = (property)=>{
        if (property === "headline") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__primary);
        if (property === "author" && hasSnippet) return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__tertiary);
        if (property === "author" && !hasSnippet) return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__secondary);
        if (property === "snippet") return (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__secondary);
        else return property.is__secondary;
    };
    const setHeadline = hasHeadline ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${(_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__headline__wrapper)} ${setTextSize("headline")}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            className: (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__headline__link),
            href: `/presents/${article.slug}`,
            children: headline
        })
    }) : null;
    const setAuthor = hasAuthor ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__author__wrapper)} ${setTextSize("author")}`,
        children: [
            "by ",
            authorsList
        ]
    }) : null;
    const setSnippet = hasSnippet ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__snippet__wrapper)} ${setTextSize("snippet")}`,
        children: [
            snippet,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: `/presents/${article.slug}`,
                children: "Read More"
            })
        ]
    }) : null;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${(_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().card__wrapper__full)} ${setTextLocation()} ${isBanner ? (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().is__banner) : null}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__image__link),
                href: `/presents/${article.slug}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__image__wrapper),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        className: (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__image__img),
                        src: article.jetpack_featured_media_url
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_ArticleCards_card_in_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__information__wrapper),
                children: [
                    setHeadline,
                    setAuthor,
                    setSnippet
                ]
            })
        ]
    });
}


/***/ }),

/***/ 1707:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Body)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9722);
/* harmony import */ var _styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var _components_Section_Style1_Section__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3161);
/* harmony import */ var _components_Section_Style2_Section__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1870);
/* harmony import */ var _components_Section_Style3_Section__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5668);
/* harmony import */ var _components_Section_Style4_Section__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2082);
/* harmony import */ var _components_Section_Style5_Section__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4833);
/* harmony import */ var _components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5266);
/* harmony import */ var _components_ArticleCards_card_in_ArticleCard__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(546);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// Swiper library












function Body({ sections  }) {
    const [isMobile, setIsMobile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const bannerArticles = sections.map((section)=>section.articles[0]);
    const handlingWindowResize = ()=>{
        setIsMobile(window.innerWidth < 750);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setIsMobile(window.innerWidth < 750);
        window.addEventListener("resize", handlingWindowResize);
    }, []);
    const sectionArticlesWrapper = sections.map((section)=>{
        if (section.name === "University") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14___default().body__section__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Section_Style1_Section__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    section: section,
                    isMobile: isMobile
                }, `${section.name}-Section__Style1`)
            }, `${section.name}-body__section__wrapper`);
        } else if (section.name === "Menagerie") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14___default().body__section__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Section_Style2_Section__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    section: section,
                    isMobile: isMobile
                }, `${section.name}-Section__Style2`)
            }, `${section.name}-body__section__wrapper`);
        } else if (section.name === "Sports") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14___default().body__section__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Section_Style3_Section__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    section: section,
                    isMobile: isMobile
                }, `${section.name}-Section__Style3`)
            }, `${section.name}-body__section__wrapper`);
        } else if (section.name === "Vanguard") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14___default().body__section__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Section_Style4_Section__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    section: section,
                    isMobile: isMobile
                }, `${section.name}-Section__Style4`)
            }, `${section.name}-body__section__wrapper`);
        } else {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14___default().body__section__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Section_Style5_Section__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    section: section,
                    isMobile: isMobile
                }, `${section.name}-Section__Style5`)
            }, `${section.name}-body__section__wrapper`);
        }
    });
    const bannerArticlesWrapper = bannerArticles.map((article)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
            children: isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_in_ArticleCard__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                article: article,
                textAlignment: "left",
                textLocation: "right",
                hasHeadline: true,
                hasAuthor: true,
                hasSnippet: false,
                hasImage: true,
                isBanner: true
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                article: article,
                textAlignment: "left",
                textLocation: "right",
                hasHeadline: true,
                hasAuthor: true,
                hasSnippet: true,
                hasImage: true,
                isBanner: true
            })
        }, `${article.id}-SwiperSlide`));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14___default().body__wrapper__full),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Body_index_Body_module_scss__WEBPACK_IMPORTED_MODULE_14___default().body__section__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
                    spaceBetween: 30,
                    loop: true,
                    pagination: true,
                    autoplay: {
                        delay: 5000,
                        disableOnInteraction: false
                    },
                    modules: [
                        swiper__WEBPACK_IMPORTED_MODULE_3__.Autoplay
                    ],
                    className: "mySwiper",
                    children: bannerArticlesWrapper
                })
            }),
            sectionArticlesWrapper
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3161:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Section)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3389);
/* harmony import */ var _styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5266);




function Section({ section , isMobile  }) {
    const primaryArticle = section.articles[1];
    const secondaryArticles = section.articles.slice(2);
    const primaryArticleWrapper = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        article: primaryArticle,
        textAlignment: "left",
        textLocation: "bottom",
        hasHeadline: true,
        hasAuthor: true,
        hasSnippet: isMobile,
        hasImage: true,
        isMobile: isMobile,
        isBanner: true
    });
    const secondaryArticlesWrapper = secondaryArticles.map((article, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().article__wrapper__full),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                article: article,
                textAlignment: "left",
                textLocation: isMobile ? "left" : "right",
                hasHeadline: true,
                hasAuthor: true,
                hasSnippet: false,
                hasImage: true,
                isMobile: isMobile,
                isBanner: false
            })
        }, `${article.id}-articleWrapperFull`));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__wrapper__full),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__title__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__title__link),
                    id: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default())[`${section.name.toLowerCase()}`],
                    href: `/section/${section.name.toLowerCase()}`,
                    children: section.name
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__articles__wrapper),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().articles__left__wrapper),
                        children: primaryArticleWrapper
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().articles__right__wrapper),
                        children: secondaryArticlesWrapper
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 1870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Section)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9624);
/* harmony import */ var _styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5266);
/* harmony import */ var _components_ArticleCards_card_in_ArticleCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(546);





function Section({ section , isMobile  }) {
    const primaryArticle = section.articles[1];
    const secondaryArticles = section.articles.slice(2);
    const primaryArticleWrapper = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        article: primaryArticle,
        textAlignment: "center",
        textLocation: "bottom",
        hasHeadline: true,
        hasAuthor: true,
        hasSnippet: true,
        hasImage: true,
        isMobile: isMobile,
        isBanner: true
    });
    const secondaryArticlesWrapper = secondaryArticles.map((article, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4___default().article__wrapper__full),
            children: isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_in_ArticleCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                article: article,
                textAlignment: "left",
                textLocation: "bottom",
                hasHeadline: true,
                hasAuthor: true,
                hasSnippet: false,
                hasImage: false,
                isMobile: isMobile,
                isBanner: false
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                article: article,
                textAlignment: "left",
                textLocation: "bottom",
                hasHeadline: true,
                hasAuthor: true,
                hasSnippet: isMobile,
                hasImage: false,
                isMobile: isMobile,
                isBanner: false
            })
        }, `${article.id}-articleWrapperFull`));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4___default().section__wrapper__full),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4___default().section__title__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4___default().section__title__link),
                    id: (_styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4___default())[`${section.name.toLowerCase()}`],
                    href: `/section/${section.name.toLowerCase()}`,
                    children: section.name
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4___default().section__articles__wrapper),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4___default().articles__left__wrapper),
                        children: primaryArticleWrapper
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style2_Section_module_scss__WEBPACK_IMPORTED_MODULE_4___default().articles__right__wrapper),
                        children: secondaryArticlesWrapper
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 5668:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Section)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8393);
/* harmony import */ var _styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5266);




function Section({ section , isMobile  }) {
    const primaryArticle = section.articles[1];
    const secondaryArticles = section.articles.slice(2);
    const primaryArticleWrapper = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        article: primaryArticle,
        textAlignment: "left",
        textLocation: "bottom",
        hasHeadline: true,
        hasAuthor: true,
        hasSnippet: true,
        hasImage: true,
        isMobile: isMobile,
        isBanner: true
    });
    const secondaryArticlesWrapper = secondaryArticles.map((article, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().article__wrapper__full),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                article: article,
                textAlignment: "left",
                textLocation: "left",
                hasHeadline: true,
                hasAuthor: true,
                hasSnippet: false,
                hasImage: true,
                isMobile: isMobile,
                isBanner: false
            })
        }, `${article.id}-articleWrapperFull`));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__wrapper__full),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__title__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__title__link),
                    id: (_styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default())[`${section.name.toLowerCase()}`],
                    href: `/section/${section.name.toLowerCase()}`,
                    children: section.name
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__articles__wrapper),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().articles__left__wrapper),
                        children: secondaryArticlesWrapper
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style3_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().articles__right__wrapper),
                        children: primaryArticleWrapper
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 2082:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Section)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9183);
/* harmony import */ var _styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5266);




function Section({ section , isMobile  }) {
    const primaryArticle = section.articles[1];
    const secondaryArticles = section.articles.slice(2);
    const primaryArticleWrapper = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        article: primaryArticle,
        textAlignment: "left",
        textLocation: "bottom",
        hasHeadline: true,
        hasAuthor: true,
        hasSnippet: true,
        hasImage: true,
        isMobile: isMobile,
        isBanner: true
    });
    const secondaryArticlesWrapper = secondaryArticles.map((article, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().article__wrapper__full),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                article: article,
                textAlignment: "left",
                textLocation: "bottom",
                hasHeadline: true,
                hasAuthor: true,
                hasSnippet: false,
                hasImage: true,
                isMobile: isMobile,
                isBanner: false
            })
        }, `${article.id}-articleWrapperFull`));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__wrapper__full),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__title__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__title__link),
                    id: (_styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default())[`${section.name.toLowerCase()}`],
                    href: `/section/${section.name.toLowerCase()}`,
                    children: section.name
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__articles__wrapper),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().articles__left__wrapper),
                        children: primaryArticleWrapper
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style4_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().articles__right__wrapper),
                        children: secondaryArticlesWrapper
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 4833:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Section)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3389);
/* harmony import */ var _styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5266);




function Section({ section , isMobile  }) {
    const primaryArticle = section.articles[1];
    const secondaryArticles = section.articles.slice(2);
    const primaryArticleWrapper = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        article: primaryArticle,
        textAlignment: "left",
        textLocation: "bottom",
        hasHeadline: true,
        hasAuthor: true,
        hasSnippet: true,
        hasImage: true,
        isMobile: isMobile,
        isBanner: true
    });
    const secondaryArticlesWrapper = secondaryArticles.map((article, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().article__wrapper__full),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ArticleCards_card_out_ArticleCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                article: article,
                textAlignment: "left",
                textLocation: isMobile ? "left" : "right",
                hasHeadline: true,
                hasAuthor: true,
                hasSnippet: isMobile,
                hasImage: !isMobile,
                isMobile: isMobile,
                isBanner: false
            })
        }, `${article.id}-articleWrapperFull`));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__wrapper__full),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__title__wrapper),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__title__link),
                    id: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default())[`${section.name.toLowerCase()}`],
                    href: `/section/${section.name.toLowerCase()}`,
                    children: section.name
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().section__articles__wrapper),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().articles__left__wrapper),
                        children: primaryArticleWrapper
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Section_Style1_Section_module_scss__WEBPACK_IMPORTED_MODULE_3___default().articles__right__wrapper),
                        children: secondaryArticlesWrapper
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 6616:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_HeaderV2_Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5613);
/* harmony import */ var _components_Body_index_Body__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1707);
/* harmony import */ var _components_Footer_Full_Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7829);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Body_index_Body__WEBPACK_IMPORTED_MODULE_3__]);
_components_Body_index_Body__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function Home({ sections  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: "The LaSallian — The bastion of issue-oriented critical thinking"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_HeaderV2_Header__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Body_index_Body__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        sections: sections
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer_Full_Footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                ]
            })
        ]
    });
}
async function getServerSideProps({ req , res  }) {
    res.setHeader("Cache-Control", "public, s-maxage=10, stale-while-revalidate=59");
    const universityResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=4");
    const universityArticles = await universityResponse.json();
    const menagerieResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=8");
    const menagerieArticles = await menagerieResponse.json();
    const sportsResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=6");
    const sportsArticles = await sportsResponse.json();
    const vanguardResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=1883");
    const vanguardArticles = await vanguardResponse.json();
    const opinionResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=5");
    const opinionArticles = await opinionResponse.json();
    return {
        props: {
            sections: [
                {
                    name: "University",
                    category: 4,
                    articles: universityArticles
                },
                {
                    name: "Menagerie",
                    category: 8,
                    articles: menagerieArticles
                },
                {
                    name: "Sports",
                    category: 6,
                    articles: sportsArticles
                },
                {
                    name: "Vanguard",
                    category: 1883,
                    articles: vanguardArticles
                },
                {
                    name: "Opinion",
                    category: 5,
                    articles: opinionArticles
                }
            ]
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9176:
/***/ (() => {



/***/ }),

/***/ 2996:
/***/ (() => {



/***/ }),

/***/ 8722:
/***/ (() => {



/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3877:
/***/ ((module) => {

"use strict";
module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [903], () => (__webpack_exec__(6616)));
module.exports = __webpack_exports__;

})();