(() => {
var exports = {};
exports.id = 438;
exports.ids = [438];
exports.modules = {

/***/ 1919:
/***/ ((module) => {

// Exports
module.exports = {
	"body__wrapper__full": "Body_body__wrapper__full__MDJKm",
	"body__background__wrapper": "Body_body__background__wrapper__03_r2",
	"background__image__img": "Body_background__image__img__wE_Yh",
	"body__foreground__wrapper": "Body_body__foreground__wrapper__rzWbb",
	"body__content__wrapper": "Body_body__content__wrapper__QzZmU",
	"body__information__wrapper": "Body_body__information__wrapper__wpKF2",
	"body__headline__wrapper": "Body_body__headline__wrapper___3SjQ",
	"body__author__wrapper": "Body_body__author__wrapper___w0bl",
	"body__date__wrapper": "Body_body__date__wrapper__E3eaM",
	"body__text__wrapper": "Body_body__text__wrapper__xDbIL",
	"body__suggestions__wrapper": "Body_body__suggestions__wrapper__jcsAt",
	"suggestions__header__wrapper": "Body_suggestions__header__wrapper__g0kln",
	"suggestions__articles__wrapper": "Body_suggestions__articles__wrapper__TsWOP",
	"university": "Body_university__X49Hp",
	"menagerie": "Body_menagerie__VDzkR",
	"sports": "Body_sports__IWQnX",
	"vanguard": "Body_vanguard__3H2FB",
	"opinion": "Body_opinion__YQYvG"
};


/***/ }),

/***/ 6518:
/***/ ((module) => {

// Exports
module.exports = {
	"body__wrapper__full": "Body_body__wrapper__full__mDzuy",
	"body__background__wrapper": "Body_body__background__wrapper__3EU5f",
	"background__image__img": "Body_background__image__img__E9BbL",
	"body__information__wrapper": "Body_body__information__wrapper__owN40",
	"body__headline__wrapper": "Body_body__headline__wrapper__Y3lPQ",
	"body__author__wrapper": "Body_body__author__wrapper__h6waE",
	"body__date__wrapper": "Body_body__date__wrapper__YvNzN",
	"body__foreground__wrapper": "Body_body__foreground__wrapper__G0HbX",
	"body__content__wrapper": "Body_body__content__wrapper__xHGfI",
	"body__text__wrapper": "Body_body__text__wrapper__Ooari",
	"body__suggestions__wrapper": "Body_body__suggestions__wrapper__mXR3P",
	"suggestions__header__wrapper": "Body_suggestions__header__wrapper__9nHXw",
	"suggestions__articles__wrapper": "Body_suggestions__articles__wrapper__5N_P5",
	"university": "Body_university__lCaSY",
	"menagerie": "Body_menagerie__Wyw7O",
	"sports": "Body_sports__0c1K7",
	"vanguard": "Body_vanguard__KuQ3S",
	"opinion": "Body_opinion__j44eg"
};


/***/ }),

/***/ 5320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ArticlePage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/HeaderV2/Header.js + 3 modules
var Header = __webpack_require__(5613);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./styles/Body/article/Mobile/Body.module.scss
var Body_module = __webpack_require__(6518);
var Body_module_default = /*#__PURE__*/__webpack_require__.n(Body_module);
// EXTERNAL MODULE: ./components/ArticleCards/card__out/ArticleCard.js
var ArticleCard = __webpack_require__(5266);
// EXTERNAL MODULE: ./components/Functions/createAuthorsList.js
var createAuthorsList = __webpack_require__(1477);
;// CONCATENATED MODULE: ./components/Functions/parseRelatedArticles.js
function parseRelatedArticles(relatedArticles) {
    const parsedArticles = relatedArticles.map((article)=>{
        const indexAdder = 16;
        const startOfSlugIndex = article.url.indexOf(".com/") + indexAdder;
        const slug = article.url.substring(startOfSlugIndex, article.url.length - 1);
        const excerpt = article.excerpt;
        const title = article.title;
        const jetpack_featured_media_url = article.img["src"];
        const date = article.date;
        return {
            title: {
                ["rendered"]: title
            },
            authors: null,
            excerpt: {
                ["rendered"]: excerpt
            },
            date: date,
            slug: slug,
            jetpack_featured_media_url: jetpack_featured_media_url
        };
    });
    return parsedArticles;
}

// EXTERNAL MODULE: ./components/Functions/dehtml.js
var dehtml = __webpack_require__(5054);
// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__(1635);
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_);
;// CONCATENATED MODULE: ./components/Body/article/Mobile/Body.js








function Body({ article , section  }) {
    const headline = (0,dehtml/* default */.Z)(article.title["rendered"]);
    const authorsList = (0,createAuthorsList/* default */.Z)(article.authors, "link");
    const dateCreated = external_dayjs_default()(article.date).format("MMMM D, YYYY");
    const relatedArticles = parseRelatedArticles(article["jetpack-related-posts"].slice(0, 3));
    const relatedArticlesCard = relatedArticles.map((article)=>/*#__PURE__*/ jsx_runtime_.jsx(ArticleCard/* default */.Z, {
            article: article,
            hasSnippet: false,
            hasAuthor: false,
            hasImage: true,
            hasDate: true
        }, `${article.slug}-articleCard`));
    const setBackgroundColor = ()=>{
        if (section === "University") return (Body_module_default()).university;
        else if (section === "Menagerie") return (Body_module_default()).menagerie;
        else if (section === "Sports") return (Body_module_default()).sports;
        else if (section === "Vanguard") return (Body_module_default()).vanguard;
        else if (section === "Opinion") return (Body_module_default()).opinion;
        else return null;
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Body_module_default()).body__wrapper__full,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${(Body_module_default()).body__background__wrapper} ${setBackgroundColor()}`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: (Body_module_default()).background__image__img,
                        src: article.jetpack_featured_media_url
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Body_module_default()).body__information__wrapper,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Body_module_default()).body__headline__wrapper,
                                children: headline
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Body_module_default()).body__author__wrapper,
                                children: [
                                    "by ",
                                    authorsList
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Body_module_default()).body__date__wrapper,
                                children: dateCreated
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Body_module_default()).body__foreground__wrapper,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Body_module_default()).body__content__wrapper,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Body_module_default()).body__text__wrapper,
                            dangerouslySetInnerHTML: {
                                __html: article.content.rendered
                            }
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (Body_module_default()).body__suggestions__wrapper,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Body_module_default()).suggestions__header__wrapper,
                                    children: "Related posts"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Body_module_default()).suggestions__articles__wrapper,
                                    children: relatedArticlesCard
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
{}
// EXTERNAL MODULE: ./styles/Body/article/Full/Body.module.scss
var Full_Body_module = __webpack_require__(1919);
var Full_Body_module_default = /*#__PURE__*/__webpack_require__.n(Full_Body_module);
;// CONCATENATED MODULE: ./components/Body/article/Full/Body.js








function Body_Body({ article , section  }) {
    const headline = (0,dehtml/* default */.Z)(article.title["rendered"]);
    const authorsList = (0,createAuthorsList/* default */.Z)(article.authors, "link");
    const dateCreated = external_dayjs_default()(article.date).format("MMMM D, YYYY");
    const relatedArticles = parseRelatedArticles(article["jetpack-related-posts"].slice(0, 3));
    const relatedArticlesCard = relatedArticles.map((article)=>/*#__PURE__*/ jsx_runtime_.jsx(ArticleCard/* default */.Z, {
            article: article,
            hasSnippet: false,
            hasAuthor: false,
            hasImage: true,
            hasDate: true
        }, `${article.slug}-articleCard`));
    const setBackgroundColor = ()=>{
        if (section === "University") return (Full_Body_module_default()).university;
        else if (section === "Menagerie") return (Full_Body_module_default()).menagerie;
        else if (section === "Sports") return (Full_Body_module_default()).sports;
        else if (section === "Vanguard") return (Full_Body_module_default()).vanguard;
        else if (section === "Opinion") return (Full_Body_module_default()).opinion;
        else return null;
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Full_Body_module_default()).body__wrapper__full,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${(Full_Body_module_default()).body__background__wrapper} ${setBackgroundColor()}`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: (Full_Body_module_default()).background__image__img,
                    src: article.jetpack_featured_media_url
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Full_Body_module_default()).body__foreground__wrapper,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Full_Body_module_default()).body__content__wrapper,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (Full_Body_module_default()).body__information__wrapper,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Full_Body_module_default()).body__headline__wrapper,
                                    children: headline
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (Full_Body_module_default()).body__author__wrapper,
                                    children: [
                                        "by ",
                                        authorsList
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Full_Body_module_default()).body__date__wrapper,
                                    children: dateCreated
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Full_Body_module_default()).body__text__wrapper,
                            dangerouslySetInnerHTML: {
                                __html: article.content.rendered
                            }
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (Full_Body_module_default()).body__suggestions__wrapper,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Full_Body_module_default()).suggestions__header__wrapper,
                                    children: "Related posts"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (Full_Body_module_default()).suggestions__articles__wrapper,
                                    children: relatedArticlesCard
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
{}
;// CONCATENATED MODULE: ./components/Body/article/Body.js




function article_Body_Body({ article , section  }) {
    const [isMobile, setIsMobile] = (0,external_react_.useState)(false);
    const handlingWindowResize = ()=>{
        setIsMobile(window.innerWidth < 750);
    };
    (0,external_react_.useEffect)(()=>{
        setIsMobile(window.innerWidth < 750);
        window.addEventListener("resize", handlingWindowResize);
    }, []);
    const setBody = ()=>{
        if (isMobile) {
            return /*#__PURE__*/ jsx_runtime_.jsx(Body, {
                article: article,
                section: section
            });
        }
        return /*#__PURE__*/ jsx_runtime_.jsx(Body_Body, {
            article: article,
            section: section
        });
    };
    return setBody();
}

// EXTERNAL MODULE: ./components/Footer/Full/Footer.js
var Footer = __webpack_require__(7829);
;// CONCATENATED MODULE: ./pages/presents/[articleSlug].js







function ArticlePage({ article , section  }) {
    const router = (0,router_.useRouter)();
    const headline = (0,dehtml/* default */.Z)(article.title["rendered"]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: headline
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                        article: article,
                        section: section
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(article_Body_Body, {
                        article: article,
                        section: section
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
                ]
            })
        ]
    });
}
async function getServerSideProps({ params  }) {
    const articleResponse = await fetch(`https://thelasallian.com/wp-json/wp/v2/posts?slug=${params.articleSlug}`);
    const articleData = await articleResponse.json();
    const article = articleData[0];
    const section = ()=>{
        if (article.categories.includes(4)) return "University";
        else if (article.categories.includes(8)) return "Menagerie";
        else if (article.categories.includes(6)) return "Sports";
        else if (article.categories.includes(1883)) return "Vanguard";
        else if (article.categories.includes(5)) return "Opinion";
        else return "None";
    };
    return {
        props: {
            article: article,
            section: section()
        }
    };
}


/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [903], () => (__webpack_exec__(5320)));
module.exports = __webpack_exports__;

})();