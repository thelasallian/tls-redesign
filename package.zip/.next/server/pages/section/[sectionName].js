(() => {
var exports = {};
exports.id = 693;
exports.ids = [693];
exports.modules = {

/***/ 5229:
/***/ ((module) => {

// Exports
module.exports = {
	"body__wrapper__full": "Body_body__wrapper__full__i5SqC",
	"body__articles__wrapper": "Body_body__articles__wrapper__49fNx",
	"articles__card__wrapper": "Body_articles__card__wrapper__KUy1d",
	"body__loading__wrapper": "Body_body__loading__wrapper__hR5QB"
};


/***/ }),

/***/ 6323:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ SectionPage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/HeaderV2/Header.js + 3 modules
var Header = __webpack_require__(5613);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./styles/Body/section/Body.module.scss
var Body_module = __webpack_require__(5229);
var Body_module_default = /*#__PURE__*/__webpack_require__.n(Body_module);
// EXTERNAL MODULE: ./components/ArticleCards/card__out/ArticleCard.js
var ArticleCard = __webpack_require__(5266);
;// CONCATENATED MODULE: ./components/Body/section/Body.js




function Body({ articles , category  }) {
    const [pageNumber, setPageNumber] = (0,external_react_.useState)(2);
    const [articleData, setArticleData] = (0,external_react_.useState)(articles);
    const [isFetching, setIsFetching] = (0,external_react_.useState)(false);
    const [isMobile, setIsMobile] = (0,external_react_.useState)(false);
    const articleCards = articleData.map((article)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (Body_module_default()).articles__card__wrapper,
            children: /*#__PURE__*/ jsx_runtime_.jsx(ArticleCard/* default */.Z, {
                article: article,
                hasSnippet: !isMobile,
                textLocation: "right",
                isBanner: false,
                cardSize: "medium",
                hasDate: true,
                isMobile: isMobile
            })
        }, `articles__card__wrapper-${article.id}`));
    const handlingWindowResize = ()=>{
        setIsMobile(window.innerWidth < 750);
    };
    (0,external_react_.useEffect)(()=>{
        setIsMobile(window.innerWidth < 750);
        window.addEventListener("resize", handlingWindowResize);
    }, []);
    const setLoading = isFetching ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Body_module_default()).body__loading__wrapper,
        children: "Fetching more articles..."
    }) : null;
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", logCurrentYValue);
    }, []);
    const logCurrentYValue = async ()=>{
        const yOffset = 491;
        const bodyWrapper = document.querySelector("." + (Body_module_default()).body__wrapper__full);
        if (bodyWrapper === null) return;
        const bodyWrapperFullHeight = bodyWrapper.offsetHeight - yOffset;
        const currentYValue = window.pageYOffset;
        if (bodyWrapperFullHeight <= currentYValue) {
            window.removeEventListener("scroll", logCurrentYValue);
            setIsFetching(true);
            const response = await fetch(`https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=20&categories=${category}&page=${pageNumber}`);
            const newData = await response.json();
            setArticleData((prevState)=>[
                    ...prevState,
                    ...newData
                ]);
            setPageNumber((prevState)=>prevState + 1);
        }
    };
    (0,external_react_.useEffect)(()=>{
        setIsFetching(false);
        window.addEventListener("scroll", logCurrentYValue);
    }, [
        articleData
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Body_module_default()).body__wrapper__full,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (Body_module_default()).body__articles__wrapper,
            children: [
                articleCards,
                setLoading
            ]
        })
    });
}

// EXTERNAL MODULE: ./components/Footer/Full/Footer.js
var Footer = __webpack_require__(7829);
;// CONCATENATED MODULE: ./components/Functions/sectionToCategory.js
function sectionToCategory(section) {
    if (section === "university") return 4;
    else if (section === "menagerie") return 8;
    else if (section === "sports") return 6;
    else if (section === "vanguard") return 1883;
    else if (section === "opinion") return 5;
    else null;
}

;// CONCATENATED MODULE: ./pages/section/[sectionName].js








function SectionPage({ sectionName , articles , category  }) {
    const sectionNameCapitalized = sectionName.charAt(0).toUpperCase() + sectionName.slice(1);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: `${sectionNameCapitalized} - The LaSallian`
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                        section: sectionNameCapitalized
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Body, {
                        articles: articles,
                        category: category
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {
                        section: sectionNameCapitalized
                    })
                ]
            })
        ]
    });
}
async function getServerSideProps({ req , res , params  }) {
    const sectionName = params.sectionName;
    const category = sectionToCategory(sectionName);
    res.setHeader("Cache-Control", "public, s-maxage=1, stale-while-revalidate=59");
    const universityResponse = await fetch(`https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=20&categories=${category}&page=1`);
    const universityArticles = await universityResponse.json();
    return {
        props: {
            sectionName: sectionName,
            articles: universityArticles,
            category: category
        }
    };
}


/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [903], () => (__webpack_exec__(6323)));
module.exports = __webpack_exports__;

})();