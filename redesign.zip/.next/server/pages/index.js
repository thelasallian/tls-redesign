(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 74:
/***/ ((module) => {

// Exports
module.exports = {
	"footer__wrapper__full": "FooterFull_footer__wrapper__full__lur9M",
	"socials__wrapper__list": "FooterFull_socials__wrapper__list__vpLrl",
	"socials__icon__facebook": "FooterFull_socials__icon__facebook___wlMK",
	"socials__icon__svg": "FooterFull_socials__icon__svg__0aM0R",
	"footer__details__wrapper": "FooterFull_footer__details__wrapper__1A0eO",
	"details__text__container": "FooterFull_details__text__container___RUDr",
	"ender__details__wrapper": "FooterFull_ender__details__wrapper__QLUqA",
	"ender__toTheTop__link": "FooterFull_ender__toTheTop__link__EAb3J"
};


/***/ }),

/***/ 559:
/***/ ((module) => {

// Exports
module.exports = {
	"header__wrapper__full": "HeaderFull_header__wrapper__full__0xT6J",
	"logo__div__full": "HeaderFull_logo__div__full__MHPip",
	"logo__link__full": "HeaderFull_logo__link__full__znQ07",
	"logo__image__full": "HeaderFull_logo__image__full__RV2D7",
	"header__navbar__full": "HeaderFull_header__navbar__full__MG_ia",
	"navbar__button__section": "HeaderFull_navbar__button__section__dkiwP",
	"navbar__link__section": "HeaderFull_navbar__link__section__jw_Zb",
	"more__button__container": "HeaderFull_more__button__container__hJrM7",
	"more__link__container": "HeaderFull_more__link__container__tH4TB",
	"more__dropdown__icon": "HeaderFull_more__dropdown__icon__Ql_N1",
	"more__list__container": "HeaderFull_more__list__container__TS0cO",
	"more__div__container": "HeaderFull_more__div__container__Zm6mt",
	"more__link__option": "HeaderFull_more__link__option__xm71J",
	"logo__link__visible": "HeaderFull_logo__link__visible__02S9k",
	"logo__image__compact": "HeaderFull_logo__image__compact__PhlR5",
	"logo__image__star": "HeaderFull_logo__image__star__BmMwi",
	"navbar__text__search": "HeaderFull_navbar__text__search__DBxzP",
	"navbar__button__search": "HeaderFull_navbar__button__search__bl_jU",
	"button__search__icon": "HeaderFull_button__search__icon__R1Fbn",
	"sticky": "HeaderFull_sticky__IYOJy",
	"sticky__for__more__options": "HeaderFull_sticky__for__more__options__UIFAK"
};


/***/ }),

/***/ 287:
/***/ ((module) => {

// Exports
module.exports = {
	"header__wrapper__holder": "HeaderMobile_header__wrapper__holder__tRNtp",
	"header__wrapper__mobile": "HeaderMobile_header__wrapper__mobile__dcBWN",
	"logo__div__mobile": "HeaderMobile_logo__div__mobile__6kp1n",
	"logo__link__mobile": "HeaderMobile_logo__link__mobile__0a_ac",
	"logo__image__mobile": "HeaderMobile_logo__image__mobile__fJerl",
	"navbar__text__search": "HeaderMobile_navbar__text__search__eydbU",
	"navbar__button__search": "HeaderMobile_navbar__button__search__U0PFu",
	"navbar__image__search": "HeaderMobile_navbar__image__search__f8P2_",
	"navbar__button__setting": "HeaderMobile_navbar__button__setting__zqtGj",
	"navbar__image__setting": "HeaderMobile_navbar__image__setting__4ou1k",
	"settings__menu__mobile": "HeaderMobile_settings__menu__mobile__wGD63",
	"settings__choices__link": "HeaderMobile_settings__choices__link__JxvsA",
	"settings__menu__choice": "HeaderMobile_settings__menu__choice__sT0yz",
	"settings__menu__choices": "HeaderMobile_settings__menu__choices__RlPwr",
	"settings__image__icon": "HeaderMobile_settings__image__icon__mN3_V",
	"sticky": "HeaderMobile_sticky__pYxla"
};


/***/ }),

/***/ 866:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: ./styles/HeaderFull.module.scss
var HeaderFull_module = __webpack_require__(559);
var HeaderFull_module_default = /*#__PURE__*/__webpack_require__.n(HeaderFull_module);
;// CONCATENATED MODULE: ./components/header/HeaderFull.js



function HeaderFull() {
    const [searchIsClicked, setSearchIsClicked] = (0,external_react_.useState)(false);
    const [pageYOffset, setPageYOffset] = (0,external_react_.useState)(0);
    const [isNavbarVisible, setIsNavbarVisible] = (0,external_react_.useState)(false);
    const [windowWidth, setWindowWidth] = (0,external_react_.useState)(0);
    const searchedSomething = (event)=>{
        const searchBar = document.getElementById("navbar__text__search");
        if (searchBar != null) {
            const searchEntry = searchBar.value.trim();
            if (event.key == "Enter" && searchEntry != "") {
                console.log("Searching:", searchEntry);
            } else if (event.key == "Escape") {
                setSearchIsClicked(!searchIsClicked);
            }
        }
    };
    const logPageYOffset = ()=>{
        setPageYOffset(window.pageYOffset);
    };
    const handlingWindowResize = ()=>{
        setWindowWidth(window.innerWidth);
    };
    //Single-responsibility useEffects
    (0,external_react_.useEffect)(()=>{
        if (searchIsClicked) {
            window.addEventListener("keydown", searchedSomething);
        } else {
            window.removeEventListener("keydown", searchedSomething);
        }
    });
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", logPageYOffset);
        const logo = document.getElementById("header__logo__full");
        const navbar = document.getElementById("header__navbar__full");
        const options = document.getElementById("more__list__container");
        setIsNavbarVisible(pageYOffset < logo.offsetHeight);
        if (isNavbarVisible) {
            navbar.classList.remove((HeaderFull_module_default()).sticky);
            if (options != null) options.classList.remove((HeaderFull_module_default()).sticky__for__more__options);
        } else {
            navbar.classList.add((HeaderFull_module_default()).sticky);
            if (options != null) options.classList.add((HeaderFull_module_default()).sticky__for__more__options);
        }
    });
    (0,external_react_.useEffect)(()=>{
        setWindowWidth(window.innerWidth);
        window.addEventListener("resize", handlingWindowResize);
    });
    const changeNavbarToSearchBar = ()=>{
        setSearchIsClicked(!searchIsClicked);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (HeaderFull_module_default()).header__wrapper__full,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (HeaderFull_module_default()).logo__div__full,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    className: (HeaderFull_module_default()).logo__link__full,
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        id: "header__logo__full",
                        className: (HeaderFull_module_default()).logo__image__full,
                        src: "/media/svg/logo--tls--full.svg"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                id: "header__navbar__full",
                className: (HeaderFull_module_default()).header__navbar__full,
                children: searchIsClicked ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            id: "navbar__text__search",
                            className: (HeaderFull_module_default()).navbar__text__search,
                            type: "text"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__search,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                onClick: changeNavbarToSearchBar,
                                className: (HeaderFull_module_default()).button__search__icon,
                                xmlns: "http://www.w3.org/2000/svg",
                                height: "48",
                                viewBox: "0 96 960 960",
                                width: "48",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "m249 849-42-42 231-231-231-231 42-42 231 231 231-231 42 42-231 231 231 231-42 42-231-231-231 231Z"
                                })
                            })
                        })
                    ]
                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        isNavbarVisible ? "" : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (HeaderFull_module_default()).navbar__button__section,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "/",
                                    className: (HeaderFull_module_default()).logo__link__visible,
                                    children: windowWidth < 900 ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderFull_module_default()).logo__image__star,
                                        src: "/media/svg/icon--tls--star.svg"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderFull_module_default()).logo__image__compact,
                                        src: "/media/svg/logo--tls--compact.svg"
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/university",
                                children: "University"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/menagerie",
                                children: "Menagerie"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/sports",
                                children: "Sports"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/vanguard",
                                children: "Vanguard"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: (HeaderFull_module_default()).navbar__link__section,
                                href: "/section/opinion",
                                children: "Opinion"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (HeaderFull_module_default()).navbar__button__section,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (HeaderFull_module_default()).more__button__container,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: (HeaderFull_module_default()).more__link__container,
                                        href: "/about",
                                        children: [
                                            "More",
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                className: (HeaderFull_module_default()).more__dropdown__icon,
                                                xmlns: "http://www.w3.org/2000/svg",
                                                height: "48",
                                                viewBox: "0 96 960 960",
                                                width: "48",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M480 697.537 253.847 471.385l32.615-32.615L480 632.924l193.538-193.539L706.153 472 480 697.537Z"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    id: "more__list__container",
                                    className: (HeaderFull_module_default()).more__list__container,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (HeaderFull_module_default()).more__div__container,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (HeaderFull_module_default()).more__link__option,
                                                href: "/about",
                                                children: "About"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (HeaderFull_module_default()).more__div__container,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (HeaderFull_module_default()).more__link__option,
                                                href: "/contact-us",
                                                children: "Contact Us"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (HeaderFull_module_default()).more__div__container,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: (HeaderFull_module_default()).more__link__option,
                                                href: "/specials/",
                                                children: "Specials"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderFull_module_default()).navbar__button__search,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                className: (HeaderFull_module_default()).button__search__icon,
                                onClick: changeNavbarToSearchBar,
                                xmlns: "http://www.w3.org/2000/svg",
                                height: "48",
                                viewBox: "0 96 960 960",
                                width: "48",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M796 935 533 672q-30 26-69.959 40.5T378 727q-108.162 0-183.081-75Q120 577 120 471t75-181q75-75 181.5-75t181 75Q632 365 632 471.15 632 514 618 554q-14 40-42 75l264 262-44 44ZM377 667q81.25 0 138.125-57.5T572 471q0-81-56.875-138.5T377 275q-82.083 0-139.542 57.5Q180 390 180 471t57.458 138.5Q294.917 667 377 667Z"
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./styles/HeaderMobile.module.scss
var HeaderMobile_module = __webpack_require__(287);
var HeaderMobile_module_default = /*#__PURE__*/__webpack_require__.n(HeaderMobile_module);
;// CONCATENATED MODULE: ./components/header/HeaderMobile.js



function HeaderMobile() {
    const [searchIsClicked, setSearchIsClicked] = (0,external_react_.useState)(false);
    const [settingsIsClicked, setSettingsIsClicked] = (0,external_react_.useState)(false);
    const searchedSomething = (event)=>{
        const searchBar = document.getElementById("navbar__text__search");
        if (searchBar != null) {
            const searchEntry = searchBar.value.trim();
            if (event.key == "Enter" && searchEntry != "") {
                console.log("Searching:", searchEntry);
            } else if (event.key == "Escape") {
                setSearchIsClicked(!searchIsClicked);
            }
        }
    };
    //Single-responsibility useEffects
    (0,external_react_.useEffect)(()=>{
        if (searchIsClicked) {
            window.addEventListener("keydown", searchedSomething);
        } else {
            window.removeEventListener("keydown", searchedSomething);
        }
    });
    (0,external_react_.useEffect)(()=>{
        if (settingsIsClicked) setSearchIsClicked(false);
    }, [
        settingsIsClicked
    ]);
    (0,external_react_.useEffect)(()=>{
        if (searchIsClicked) setSettingsIsClicked(false);
    }, [
        searchIsClicked
    ]);
    const changeNavbarToSearchBar = ()=>{
        setSearchIsClicked(!searchIsClicked);
    };
    const openSettingsMenu = ()=>{
        setSettingsIsClicked(!settingsIsClicked);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (HeaderMobile_module_default()).logo__div__holder
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (HeaderMobile_module_default()).header__wrapper__mobile,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (HeaderMobile_module_default()).navbar__button__setting,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (HeaderMobile_module_default()).navbar__image__setting,
                            onClick: openSettingsMenu,
                            xmlns: "http://www.w3.org/2000/svg",
                            height: "48",
                            viewBox: "0 96 960 960",
                            width: "48",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M110.391 831.827v-79.218h739.218v79.218H110.391Zm0-216.218v-79.218h739.218v79.218H110.391Zm0-216.218v-79.783h739.218v79.783H110.391Z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (HeaderMobile_module_default()).logo__div__mobile,
                        children: searchIsClicked ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                id: "navbar__text__search",
                                className: (HeaderMobile_module_default()).navbar__text__search,
                                type: "text"
                            })
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: (HeaderMobile_module_default()).logo__link__mobile,
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                id: "header__logo__full",
                                className: (HeaderMobile_module_default()).logo__image__mobile,
                                src: "/media/svg/logo--tls--compact.svg"
                            })
                        })
                    }),
                    searchIsClicked ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (HeaderMobile_module_default()).navbar__button__search,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (HeaderMobile_module_default()).navbar__image__search,
                            onClick: changeNavbarToSearchBar,
                            xmlns: "http://www.w3.org/2000/svg",
                            height: "48",
                            viewBox: "0 96 960 960",
                            width: "48",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M249 862.566 193.434 807l231-231-231-231L249 289.434l231 231 231-231L766.566 345l-231 231 231 231L711 862.566l-231-231-231 231Z"
                            })
                        })
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (HeaderMobile_module_default()).navbar__button__search,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (HeaderMobile_module_default()).navbar__image__search,
                            onClick: changeNavbarToSearchBar,
                            xmlns: "http://www.w3.org/2000/svg",
                            height: "48",
                            viewBox: "0 96 960 960",
                            width: "48",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M795.435 950.827 529.043 685.001q-29.434 24.26-69.111 37.934-39.676 13.674-85.323 13.674-112.119 0-189.864-77.826Q106.999 580.957 106.999 471t77.827-187.783q77.826-77.826 188.283-77.826 110.456 0 187.782 77.826 77.327 77.826 77.327 187.933 0 43.98-13.152 83.133-13.153 39.152-39.457 73.587l267.392 265.391-57.566 57.566ZM373.808 657.391q77.659 0 131.425-54.533Q558.999 548.326 558.999 471q0-77.326-53.849-131.858-53.849-54.533-131.342-54.533-78.326 0-132.958 54.533Q186.218 393.674 186.218 471q0 77.326 54.549 131.858 54.549 54.533 133.041 54.533Z"
                            })
                        })
                    })
                ]
            }),
            settingsIsClicked ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: (HeaderMobile_module_default()).settings__menu__mobile,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/university",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "University"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/menagerie",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Menagerie"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/sports",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Sports"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/vanguard",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Vanguard"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/section/opinion",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Opinion"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/about",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "About"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/contact-us",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Contact Us"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: (HeaderMobile_module_default()).settings__choices__link,
                        href: "/specials",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_module_default()).settings__menu__choice,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (HeaderMobile_module_default()).settings__menu__choices,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        className: (HeaderMobile_module_default()).settings__image__icon,
                                        src: "/media/svg/icon--search.svg"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (HeaderMobile_module_default()).settings__text__choices,
                                        children: "Specials"
                                    })
                                ]
                            })
                        })
                    })
                ]
            }) : ""
        ]
    });
}

;// CONCATENATED MODULE: ./components/header/Header.js




function Header() {
    const [windowWidth, setWindowWidth] = (0,external_react_.useState)(0);
    const handlingWindowResize = ()=>{
        setWindowWidth(window.innerWidth);
    };
    //Single-responsibility useEffects
    (0,external_react_.useEffect)(()=>{
        setWindowWidth(window.innerWidth);
        window.addEventListener("resize", handlingWindowResize);
    }, []);
    if (windowWidth < 750) {
        return /*#__PURE__*/ jsx_runtime_.jsx(HeaderMobile, {});
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx(HeaderFull, {});
    }
}

;// CONCATENATED MODULE: ./components/body/index/Body.js


function Body() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "body",
        children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores, explicabo. Nemo vel maxime voluptatem culpa cumque. Quidem dolorem culpa voluptatum tempora necessitatibus aspernatur alias, asperiores cupiditate itaque quaerat error id maxime, unde facere aliquid laboriosam sunt aut eaque, similique labore tenetur magni natus. Eius minus eaque quos laborum rem qui natus. Animi, ex ratione assumenda fugit unde culpa nobis repudiandae possimus, incidunt at mollitia iure voluptatem doloremque minus veniam sint, cupiditate sunt debitis consequuntur! Magnam doloribus in, minus et asperiores architecto modi labore, laboriosam deserunt cum perspiciatis! Veritatis voluptatum recusandae sed alias nam, maxime vitae! Eveniet ratione, illo commodi animi molestias quia sint, consectetur sapiente repudiandae cupiditate, architecto distinctio amet possimus eum excepturi odio cum. Temporibus in ratione recusandae possimus expedita modi ullam commodi non ipsam, velit porro maiores consectetur perferendis corrupti optio iusto provident facere tempore eius est vitae. Modi ipsam impedit, quibusdam libero et a nesciunt, veniam itaque ab nam omnis soluta dolorem nulla quod cum cupiditate iste saepe aut, esse sed ea nostrum quidem. Fugiat perspiciatis earum aperiam incidunt. Dolorem impedit doloremque libero laboriosam doloribus voluptate consequuntur expedita facilis quasi porro maxime itaque amet non, tenetur iure a quis eos placeat voluptas eveniet odit quae? Perferendis, omnis, nihil incidunt mollitia ducimus beatae suscipit atque error voluptates magni, similique eveniet fuga enim dicta eius obcaecati explicabo commodi molestias doloremque quos sint? Odio recusandae unde ab, velit dolorum atque ipsam aut blanditiis architecto illum iure iusto expedita aliquam fuga, adipisci ducimus saepe harum accusantium sit eveniet! Delectus excepturi voluptatum consequuntur porro aperiam in dolor aliquid quas odio, voluptas quae. Accusamus harum sequi iure numquam nulla a corporis totam, eius deleniti adipisci, ut dolorum! Atque voluptas cupiditate porro debitis. Deserunt ratione ipsa quaerat eos quo, voluptatem optio necessitatibus assumenda earum tenetur dolore, neque facilis magni accusantium quibusdam excepturi! Magni maxime incidunt quia quaerat nam! Laudantium necessitatibus et sapiente ipsum, ipsa placeat deserunt voluptatum reiciendis quas provident, ratione nihil sit illo, odio voluptates odit dignissimos. Repellendus quae est, alias saepe necessitatibus, voluptatibus cumque voluptate ipsa distinctio numquam officia iste nihil possimus sed eos eaque a atque animi. Eligendi delectus quod vel fugit hic molestiae consequatur tempore vero ad totam asperiores assumenda quaerat officia velit ipsa, quos quo a maiores, esse repellat alias? Iusto eligendi, possimus vel natus libero debitis! Sequi, in repellat iste ipsum dolorum sint error unde sunt neque ducimus adipisci sed, eligendi quam commodi animi nostrum accusamus eius? Reiciendis recusandae id non iusto sunt corporis deleniti nam dignissimos repellat, adipisci saepe, nulla aliquid. Doloribus impedit error et voluptatibus at tempora. Natus quia explicabo iusto veritatis, ad maiores non porro qui at reiciendis autem praesentium unde vero in. Laboriosam alias reiciendis nisi nobis corporis ratione ad magni itaque quod officiis. Molestiae quod, praesentium explicabo quaerat modi dolorem in impedit aliquid, deserunt perspiciatis sed iste vero non voluptate repellendus placeat aliquam maiores. Magni deleniti sint nemo, modi odio facere laudantium distinctio rerum. Ea, aut molestiae. Ut iure praesentium molestiae laboriosam aliquam dolorem accusamus repellat illum. At consectetur facilis quia necessitatibus dicta, doloremque quibusdam accusamus dolorum? Quaerat, delectus expedita minus non esse ipsa! Animi, nemo veniam dicta nam maiores, magni vero obcaecati fugiat totam asperiores perspiciatis tempore nihil accusamus laudantium magnam cumque ad! Maiores ratione nemo vitae sint modi at ab cupiditate delectus, dicta voluptatibus obcaecati natus accusamus assumenda ea! Necessitatibus minus excepturi aut, hic quisquam molestias rem animi blanditiis eveniet! Esse est accusantium vel ut deleniti iusto? Ad ullam, enim molestias neque repellendus nam, similique natus voluptas cum placeat optio aperiam mollitia odit voluptatum, voluptatibus ducimus iste autem. Veritatis quod dolores, qui eum ipsam itaque molestias tempore autem unde facilis fuga ipsa quasi quos ex ea reiciendis dignissimos maiores, voluptas minima esse, repellat quibusdam. Sint fugit adipisci voluptatem minus ex esse, beatae iste eum ab alias error repellat vel odio quaerat nostrum quas cupiditate maxime id? Vel molestiae neque illum nam ex repudiandae ipsam sed id! Rerum quia odio praesentium laudantium, dolorem ex, possimus earum tempora reiciendis eius ad aliquid iure quisquam ea assumenda voluptatem, quod aspernatur incidunt consectetur. Illo voluptate odio ratione. Aspernatur magnam incidunt cupiditate id perspiciatis aliquid cum dolor dolores totam excepturi molestiae, illum quo! Quas officia labore suscipit excepturi sapiente vero expedita reiciendis, facilis explicabo ex totam iste cupiditate hic pariatur provident cum numquam libero accusamus impedit? Officia id a reiciendis, eveniet aliquid ea placeat sint numquam magni at odit voluptates ut nobis quidem quam facere nostrum fugit beatae? Rem voluptate hic nisi doloribus recusandae quam officiis, quaerat animi sit ad eius molestiae ipsa harum labore voluptatem commodi vel ipsam, et fugit qui esse consequuntur assumenda repellendus? Adipisci, illum culpa. Dolorem et maiores, natus expedita ipsam, illum veritatis est libero id assumenda obcaecati error rem consectetur qui hic quo doloremque quis rerum quasi eaque dicta. Dicta nostrum eligendi voluptatibus rerum temporibus ex placeat assumenda. Dicta, nulla fugiat rem ad quos consequatur, itaque doloremque ea officiis eos excepturi quis saepe impedit. Impedit minima odit reiciendis! Itaque tempora reiciendis iste eligendi similique magnam ducimus molestias, qui officia facere consequuntur corporis consectetur ipsum animi exercitationem ab quas omnis esse eum nulla rerum, ut blanditiis asperiores libero! Molestiae nostrum assumenda magni quidem ad ipsam, enim error, ratione nesciunt facilis odit culpa totam sed excepturi minus unde maxime? Sint quod a, aspernatur tempore minus quae eius reiciendis doloribus nam! Quasi quisquam porro perferendis! Ad doloribus harum vero. Sint incidunt ut, ullam porro corporis, suscipit ea id cum modi architecto error iusto, esse praesentium repellat omnis. Neque error asperiores, dicta, praesentium laboriosam aut quae dolores soluta iure odit assumenda, voluptas non accusamus. Voluptas temporibus eos, rem sint in laudantium. Eligendi delectus suscipit maxime quidem consequatur laboriosam dolore impedit saepe qui reprehenderit provident deserunt voluptas repellendus et fugiat cumque atque illum incidunt, nemo quis praesentium! Amet hic cum cumque earum, voluptatem consequatur quo ducimus beatae error deserunt rem odio architecto! Fugit iusto, quod quae iste provident nemo totam eligendi, magnam nulla ipsum ullam suscipit esse laboriosam impedit odit voluptates repellendus eveniet sed libero accusantium quia. Commodi reiciendis, necessitatibus quas non tempore deserunt veritatis at minima ducimus pariatur repellat voluptate eum dolore quisquam similique in harum atque facere eos! Aspernatur, voluptatum provident quam, atque distinctio debitis, nihil fuga at officiis corporis obcaecati culpa id inventore velit quibusdam saepe cum? Delectus corporis totam perspiciatis, magnam eum impedit rerum est fugit, similique harum ut veritatis dicta culpa reiciendis nisi! Debitis omnis, asperiores ducimus nihil, doloremque eos reiciendis vel iure saepe maiores praesentium libero quisquam minima sit minus velit! Rerum magni nobis eveniet reiciendis quia, nesciunt a libero officia impedit repudiandae perferendis. Soluta unde cumque, hic odio aperiam reprehenderit iure quam iste eveniet, voluptate natus quaerat sed rem, aliquam minima numquam. Impedit nobis inventore illo quisquam voluptas? Id ad incidunt sunt rem laudantium esse a, culpa iste sapiente recusandae in cumque nesciunt minus! Possimus architecto quis natus cum impedit sed consequuntur sequi. Corporis doloremque magni nostrum laborum iste, necessitatibus inventore adipisci voluptas delectus voluptatum sunt dolores veritatis eos harum vero commodi fugiat odit distinctio rem optio aspernatur. Accusamus quaerat suscipit eum eos eaque rem inventore omnis? Ratione suscipit adipisci deserunt ipsam nam? Ex aliquid necessitatibus, maxime repellat nesciunt optio? Temporibus unde debitis quaerat, vero dolor id nihil numquam quisquam voluptatibus, corporis nemo doloremque rem suscipit ipsa? Sit voluptatibus quas minus hic omnis repellendus libero porro, expedita aliquam animi esse, laborum cupiditate debitis. Iusto amet aut deleniti placeat assumenda veniam similique ipsum error quae dignissimos! Odit dolores dolorum dolorem repudiandae distinctio minus molestiae sint, suscipit aspernatur cum, tempore ad, in architecto ipsam quibusdam recusandae beatae necessitatibus nulla? Eaque, adipisci dolore mollitia voluptatibus dolores et deserunt maxime. Qui, illum accusamus enim voluptas expedita officia aliquid maxime incidunt. Natus ut deleniti iusto ducimus maxime laudantium inventore nulla! Eveniet eos nam veniam fuga, in similique accusantium? Sint nemo assumenda voluptas blanditiis nesciunt consequatur, reprehenderit sequi. Eius similique, itaque suscipit fugiat unde minus. Possimus dolore nobis magnam ab delectus sunt labore ipsa nemo laboriosam, distinctio eaque, ullam ducimus quod! Quae ipsum dolorum, alias excepturi explicabo dolor iure, omnis error, natus necessitatibus delectus molestiae blanditiis officia praesentium et odit corporis repellat qui doloribus repudiandae reprehenderit magnam? Ipsum ipsa sit quam, aliquam amet, dolores odio tempora culpa dicta officia neque explicabo cum consequatur est, ea a sint minus provident. Consequuntur dolor sequi maiores repellendus. Possimus fuga ut reiciendis veniam est suscipit porro. Impedit voluptate vel, ullam amet qui dolor nemo voluptatem praesentium, quod magnam suscipit? Perspiciatis veniam veritatis repudiandae, reprehenderit ea mollitia doloribus in deleniti earum totam voluptates quia incidunt quibusdam dolore atque! Dicta, dolores quasi recusandae ad fugit delectus deleniti? Expedita maxime consequatur delectus officiis accusantium dolorem cupiditate ducimus porro, aut odio voluptatibus soluta amet. Blanditiis reprehenderit voluptates expedita voluptas rem omnis itaque excepturi, pariatur, tenetur rerum magni magnam cum quas corrupti dolor? Aut molestiae, eos repudiandae molestias eaque inventore voluptates officiis pariatur ratione explicabo. Tenetur quis explicabo obcaecati, maiores cum id facere non suscipit earum adipisci magni voluptas? Hic iure illo quod, in cupiditate consequuntur? Amet rem aperiam eveniet in similique architecto, provident ipsa sit qui eligendi quam, excepturi alias molestiae, est voluptatum laborum incidunt repellendus voluptatem! Rerum quibusdam, quis quo nam earum nulla temporibus fugit accusantium atque sapiente esse mollitia harum maiores sit autem est totam. Omnis recusandae animi alias totam reprehenderit provident cum maxime officia? Nobis, repellendus illo corporis harum obcaecati ratione impedit sunt eius accusamus ipsum praesentium libero ab porro? Voluptas dicta officia necessitatibus harum impedit optio molestias fugit reiciendis numquam. Nulla necessitatibus quis officia cum obcaecati, id, corrupti ducimus dolores distinctio consequuntur maiores placeat possimus sit quam eos harum atque quod minima tempore. Accusamus iure quibusdam ad ipsa, aperiam distinctio unde perferendis quas nesciunt asperiores nisi alias praesentium eum ipsum officiis maiores deserunt molestias, in nam obcaecati et, ullam sed. Cupiditate repudiandae temporibus culpa voluptatem! Sit ab reprehenderit libero iusto quisquam sequi consequuntur cupiditate, temporibus dicta nemo natus vel in blanditiis ex laboriosam? Nisi voluptas repellat ab quas earum quis commodi accusamus fuga assumenda tempora itaque doloribus architecto animi, excepturi officia, distinctio voluptatum repellendus. Similique, mollitia. Accusamus nemo voluptatem inventore, pariatur tempore cupiditate quia reprehenderit? Animi corrupti temporibus, a dicta necessitatibus dolores et explicabo dolore. Dignissimos alias sed inventore voluptatibus nobis doloremque omnis tenetur deleniti beatae fugit vel, laudantium exercitationem dolor. Ducimus earum cum iste, laborum quibusdam ipsam ab sint nobis nam enim dolor veniam nemo vel quidem illo similique dignissimos nulla odit, dicta dolores praesentium quos vitae. Vero distinctio doloribus natus nemo repellat fugiat! Aspernatur quod alias, atque, tempore asperiores earum accusamus cum dolor libero quam exercitationem dolorem! Veritatis ratione placeat quisquam quos ut sint. Accusantium aspernatur nam, qui sunt totam quisquam, rerum dignissimos voluptates quibusdam velit iure! Dolore consectetur corrupti numquam provident laudantium nisi nulla! Veniam inventore adipisci illo facilis quisquam. Est voluptates, neque soluta aperiam asperiores officia voluptate at reiciendis delectus voluptatibus itaque iure illo consectetur dolor? Nulla ullam magni maiores reprehenderit facilis autem, veritatis doloribus veniam unde, perferendis voluptates! Voluptatem vel, sequi quo itaque, mollitia ipsum tempora voluptas excepturi laboriosam laborum, repellat magni sit quasi iusto harum dolorum eaque consequuntur. Animi fugit hic eligendi esse excepturi inventore dolor. Eligendi architecto ipsam suscipit error sunt reprehenderit soluta deleniti mollitia adipisci odit molestias nam, vitae dolorem laboriosam tempore voluptatum est vel dolore quis repellat commodi excepturi eaque ad. Ullam itaque nulla quibusdam earum! Optio id dolore dolorem enim voluptatum nostrum fugiat, impedit doloribus repudiandae. Veniam perferendis impedit eaque quod? Sunt, maiores sed labore ut quasi porro consequatur rerum fugiat alias tempora a deserunt nam aspernatur velit aperiam natus provident itaque! Nisi vero eaque, recusandae rem ducimus accusamus optio nam ullam debitis, officiis labore aut quis provident dolorum alias quibusdam iste quod hic obcaecati mollitia omnis corporis? Ea voluptatibus at culpa esse officia cumque porro nesciunt? Quisquam, expedita voluptate? Repellat consequuntur, illum accusantium soluta dignissimos sapiente dolorem velit deleniti exercitationem illo itaque quisquam aspernatur nostrum iste, ab aliquam delectus nihil neque autem aliquid qui officiis quia eligendi inventore? Assumenda architecto accusamus molestias laudantium voluptates veniam, dolorum pariatur corporis voluptas itaque vel cum accusantium ipsam iure quibusdam, animi laboriosam. Sit eaque suscipit ea dolore dicta odit quidem totam iure! Repudiandae architecto, minima dolore dignissimos eius repellendus deserunt quis sit eos beatae. Ad neque quaerat ratione necessitatibus. Expedita eveniet natus fuga laborum quidem ab et fugit dolores non repellendus, sequi quia numquam laboriosam est! Consectetur at ex neque totam aliquid iusto ipsum modi quae, odio facere, est rerum a ad sint tempore iure soluta repellat tenetur voluptatibus ipsam veniam. Consequatur deserunt beatae vel deleniti ipsum nostrum, reprehenderit quibusdam nesciunt commodi at cum ducimus eius provident maxime saepe vero tempore veniam sint. Fuga harum, porro sit sint illo aspernatur. Consequuntur consectetur dolorum accusamus asperiores reprehenderit excepturi repellendus cumque blanditiis debitis repudiandae maxime fugiat sint tempore eum, doloribus et numquam? Quisquam, doloribus neque dolorem, praesentium laboriosam nesciunt molestias esse repellendus eum non reiciendis labore eveniet fugit deleniti quibusdam, cum similique sunt quam nisi. Facilis repudiandae deleniti laboriosam. Error sequi quo nihil facere alias quos rem excepturi qui neque non laudantium soluta provident nesciunt praesentium optio, debitis possimus enim distinctio, corporis labore esse beatae officia earum. Earum, molestiae, beatae eligendi ducimus cumque unde accusamus, sapiente aperiam sed doloribus dolores neque nulla veniam veritatis magnam. Commodi ad veniam suscipit quas perferendis voluptas deserunt labore at quae, dicta a accusantium ducimus incidunt consectetur assumenda nihil quidem cumque rem architecto blanditiis eligendi voluptatum dolor. Quas veniam neque suscipit quasi debitis dolore soluta sit illum cum quisquam. Aliquam officia voluptate ut blanditiis delectus saepe sapiente minima obcaecati optio facere impedit, doloribus consectetur exercitationem eos id at ex culpa a dicta odit molestias. Dolore error reprehenderit assumenda voluptatem repellat perferendis suscipit alias expedita, vel molestias itaque vero repudiandae omnis et officia saepe numquam? Id maxime ad sapiente, natus rerum quisquam non sint? Ullam ipsa fugiat ut consequuntur modi. Modi assumenda dolor totam quas voluptas nam velit officia aut fugit omnis accusantium dolores aperiam odio magni, consequatur unde cupiditate laboriosam veniam incidunt harum ipsum ex tempora. Cum fuga corrupti aut earum asperiores temporibus et suscipit deleniti exercitationem doloremque? Voluptates quas unde ea dolorem quibusdam vero nihil voluptatum rerum quasi, excepturi id culpa voluptatem veritatis corrupti, facere numquam voluptatibus dolores, minus et dicta repellendus. Cumque porro sapiente asperiores eius magnam, neque est recusandae incidunt culpa. Quaerat esse dolore amet maxime soluta quia quae odit quam error officia reiciendis, placeat sequi tenetur iure reprehenderit modi tempore ducimus doloribus sed! Voluptates corrupti aspernatur aliquid doloribus quisquam incidunt ad non harum nobis sunt maiores eius provident, sit tempore odio fugiat a quo vitae debitis? Quibusdam officiis quo ducimus laborum perspiciatis qui iusto repudiandae. Illo iure nulla laboriosam provident accusantium ea sapiente molestiae qui dolorem temporibus? Ab repudiandae culpa vel eum voluptatum nemo, accusamus ex modi. Possimus consectetur doloribus quo cumque facere quidem dolorum nam laudantium. Mollitia aut eligendi minima consequuntur deserunt! Accusamus ea id temporibus est, rem, nisi, et praesentium error vitae ipsa perspiciatis ad ratione ducimus commodi? Accusantium ut, sint alias temporibus nobis harum quia fugiat commodi deleniti perferendis optio delectus blanditiis maxime asperiores natus culpa, dolores eius! Hic quibusdam consequuntur nobis neque, magni recusandae quia commodi laboriosam voluptatem aliquid in molestias error vitae nemo beatae a adipisci mollitia labore quae cum eligendi alias quos blanditiis! Inventore error nam cupiditate eos vero, veritatis labore, quaerat consectetur non, id quia? Aperiam, nobis ducimus eveniet id ut repellendus sequi tempore tempora, itaque quam quae! Sint quis quas enim suscipit! Dolores, aperiam. Perferendis voluptatibus nam, doloribus error non aut ab magnam facilis tenetur libero quam amet, aspernatur unde vitae quos optio dicta praesentium repudiandae. Eius doloribus, voluptates facere beatae tempora cupiditate! Recusandae aspernatur sit repellendus? Similique nam nostrum velit dignissimos quis nobis maxime. Aut quae aspernatur expedita eligendi voluptas distinctio voluptate id ipsam atque impedit amet, commodi, fuga, libero tempore quo mollitia. Nostrum, dolores facilis quia voluptate temporibus saepe magni architecto fugit porro sint repudiandae! Id explicabo incidunt eligendi placeat mollitia tempore cupiditate quam nobis laborum eius, quod porro asperiores quasi dolorem officiis? Obcaecati, aliquam. Veritatis necessitatibus perferendis eveniet est neque officia impedit aut earum odit vero ab exercitationem qui, reprehenderit magnam provident quos! Eaque quidem possimus ipsa maxime dolorum impedit, quibusdam minima laboriosam ut veniam esse ab illum officia aliquam, ducimus adipisci quos aut dolores voluptatem rerum saepe odio dolor consequuntur. Odio totam molestiae ad culpa laudantium, dolorum dolores qui neque, distinctio non quae voluptatibus voluptatem amet sequi, dolor voluptatum in. Natus facere asperiores voluptatem. Unde distinctio laborum nihil amet magni iste omnis nam ex, numquam ut est illo! Perferendis, magni sunt necessitatibus sint consequatur neque! Ullam rerum necessitatibus placeat beatae deserunt in eum delectus provident explicabo quae? Deserunt eaque deleniti obcaecati aut corrupti. Dolore qui consequuntur aut hic rem autem voluptate, atque praesentium pariatur, harum beatae quibusdam, adipisci saepe? Necessitatibus consequuntur ipsam exercitationem facere quasi quam et ipsum facilis dolor. Odit itaque beatae dolorem animi, iusto facere accusantium eius perferendis velit sapiente quibusdam veniam ullam illo vero ipsa molestiae nisi quod laborum! Odio, quibusdam at voluptatibus consequuntur soluta animi libero placeat temporibus dolor veritatis vitae delectus quos. Eveniet aut accusantium, assumenda optio exercitationem rem, ipsam illo totam, molestiae facere consectetur inventore dignissimos distinctio nesciunt sapiente sed quos asperiores vel corrupti. Incidunt rem placeat dolor? Quaerat nemo exercitationem culpa necessitatibus quidem dolor, voluptatem aspernatur quo similique voluptate blanditiis, accusamus veniam quis nisi non cum fuga dignissimos adipisci corporis quibusdam quisquam maiores doloribus! Ullam saepe iste eos facere eum? Neque quia maxime facere, sed modi id mollitia repellat! Quod beatae praesentium quos voluptates? A incidunt adipisci, modi quisquam deleniti sapiente repudiandae reiciendis accusantium aut laudantium alias rerum. Et ipsum aut numquam, quod ex modi aliquid recusandae voluptatum, quia amet repellat voluptatibus adipisci ducimus iure laudantium expedita labore praesentium, a consectetur reiciendis possimus? Dolorem vero, ullam perferendis ratione ipsa, recusandae ipsum vitae consectetur sed inventore laboriosam rerum dignissimos maiores, voluptatibus at fugit doloribus. Delectus officia dolorem recusandae repudiandae, suscipit eius nulla, corrupti ratione quod labore molestias vitae quis iusto dolorum voluptates. Porro qui nam hic saepe reprehenderit tempore fugit beatae nisi asperiores officiis commodi dolor, dolores odit error. Dolorem, sapiente. Corporis harum iure hic sequi! Iure totam distinctio, sint ut fuga iusto. Commodi, nesciunt obcaecati corporis soluta pariatur nobis inventore rerum quis! Vitae obcaecati inventore ex mollitia voluptate, vero temporibus ullam cum reiciendis veritatis impedit dolores optio nulla qui labore iste soluta consequatur ipsa veniam, placeat architecto delectus quae dolorem ea! Hic temporibus eveniet quidem similique reiciendis culpa ratione corporis? Ad, iure consequatur mollitia rerum non soluta velit fugiat nisi cupiditate suscipit rem earum porro ipsa aperiam, libero sapiente tempora error. Itaque explicabo libero sequi perferendis officiis modi iste suscipit, nisi ab recusandae? Incidunt commodi eveniet odit magnam, molestiae fuga ipsam doloribus doloremque magni laboriosam voluptas, exercitationem tempora? Exercitationem, veritatis repellat cum ipsam vel velit. Esse impedit rem repellat vero iure, dignissimos aperiam ab sit neque vitae nobis non accusamus quo suscipit voluptate maiores laborum debitis in dolorem nemo voluptatem sed doloremque hic. In sit earum quos voluptates at enim ipsum eos veritatis maxime. Molestias sed tempore similique pariatur ad, commodi ut excepturi error nulla neque ab, dignissimos soluta nostrum vero repellat sit! Eos vero ad ratione culpa reprehenderit labore nostrum corrupti voluptates soluta quibusdam dolore molestiae itaque, aut voluptas earum autem in! Odio, velit optio voluptatum exercitationem quia rem voluptate? Enim tempora est culpa fugiat iusto aperiam debitis blanditiis ab sed. Debitis incidunt libero sit aut? Est tempora consectetur, laborum atque ullam veniam. Sint tempora, nobis hic ipsa inventore neque dicta fugiat voluptatibus blanditiis deserunt tempore distinctio minus enim, atque iusto? Deleniti aliquam ullam vero rem, ad quasi placeat veniam doloribus atque, nam est cupiditate. Quae aut, praesentium consequuntur soluta accusantium, repudiandae at doloribus nobis sed mollitia laborum magnam laboriosam ipsum inventore saepe voluptate impedit unde? Accusantium possimus beatae facere excepturi odit sint. Eligendi, dolor, necessitatibus quos odio error quo voluptatibus reprehenderit, ab cum et itaque velit molestiae reiciendis quibusdam. Iste natus voluptate perferendis ab, vero eius, saepe temporibus quibusdam et soluta eligendi illum assumenda similique dolore quam fugiat iure culpa corrupti, ut autem dolorum quis. Nisi reiciendis optio ut suscipit omnis placeat dolor culpa quas vel corrupti accusantium hic veritatis, officia nostrum obcaecati deserunt distinctio nulla dolores dolore quos, illum fuga. Sequi voluptate facilis at, nam accusamus odio aut deleniti exercitationem consequuntur ab voluptas alias mollitia obcaecati corrupti, perferendis ex quasi non quis dignissimos iusto veritatis rem neque! Debitis dolor, exercitationem doloribus sit qui aperiam, reprehenderit ad similique, ipsa dolorem natus repellat? Velit ratione inventore accusantium laborum suscipit similique soluta officia laudantium. Quo voluptatum tempore maiores soluta eligendi minima quibusdam, magnam laboriosam nostrum. Maxime, dolorum praesentium? Inventore eaque enim assumenda possimus dolorum repellendus ipsa, itaque ratione ex facilis consequatur quis ab porro error, natus aliquam, fuga iure accusantium illum sequi ipsam sint suscipit ad molestiae. Veniam ab iste illum, aliquam assumenda similique dolore, laborum ea dicta, autem et libero! Porro non nostrum cum, ratione vitae laudantium velit enim unde tempore magnam aperiam. Esse numquam exercitationem porro tempora ullam in eos quisquam, optio est accusantium, sint doloremque? In, ex incidunt? Perferendis minus consectetur recusandae quam a dolorum magnam dolore sit quae, earum tempora cum ad! Quos libero aperiam voluptatibus tempore modi, repellendus voluptatem! Consequuntur quidem obcaecati, animi vel similique tempore ullam nulla doloremque possimus at non, voluptas iusto veritatis deserunt asperiores cupiditate maxime autem eius, dolorem impedit. Facere voluptate fuga odio earum sequi amet, maxime placeat reiciendis suscipit hic corporis nulla adipisci magni beatae quisquam nihil aut. Quam repellendus vitae sint eveniet assumenda suscipit pariatur provident, temporibus voluptatibus corrupti dicta enim accusantium molestiae earum corporis commodi eligendi harum. Ducimus ab pariatur commodi eveniet voluptatibus, placeat distinctio unde. Explicabo neque, facilis odio, commodi aspernatur voluptatibus, est quos tempora fuga quas suscipit. Maiores, modi veniam? Eos quia eaque enim ut neque architecto quod ipsum accusamus libero quos nulla consequatur sint suscipit recusandae explicabo aperiam sit minus numquam ad, illum porro et, harum amet. Nobis consequatur, quod asperiores autem obcaecati possimus molestias magnam eos, tempore a quos animi ducimus corrupti aliquam sint alias architecto quaerat unde culpa dicta accusamus iusto, suscipit ullam. Illo facilis beatae, voluptas maiores dolor harum eius delectus ut tempore! At porro dignissimos voluptates deserunt minus dolorum animi ex labore sunt alias dolorem, minima id a odio nemo aspernatur in voluptate fuga veniam veritatis cumque numquam. Unde odit quos repellendus doloremque odio nesciunt explicabo. Quia cumque ea eaque perspiciatis similique quaerat commodi iure nisi, recusandae, expedita, eligendi rem veniam magni culpa possimus necessitatibus! Facere officiis repudiandae iusto doloribus tenetur quae repellat! Ratione, delectus exercitationem ipsum numquam ullam saepe. Pariatur reiciendis praesentium labore sint commodi itaque excepturi ipsam autem, aut dignissimos magnam consectetur! Quo quia sit adipisci! Voluptates, optio quo sit ullam ipsam laudantium quidem reprehenderit. Omnis tempore, fugit ad magnam impedit, quis nesciunt temporibus unde numquam dolorem maxime excepturi? Excepturi incidunt dolor nesciunt numquam accusamus provident ratione magnam qui fugit harum tempore vero aspernatur sequi culpa exercitationem id cumque aperiam ea, consequuntur quia iste. Excepturi quidem aspernatur id aperiam, explicabo delectus sunt et nemo cumque vero quod nostrum dolor, necessitatibus beatae quibusdam nobis aliquam dicta atque veritatis dolorem minus? Similique quos labore voluptatibus assumenda tenetur animi laudantium dignissimos aut voluptas, esse, quas ipsam fuga libero sequi necessitatibus. Eos ratione, deserunt cupiditate voluptatum magni eligendi nesciunt sapiente similique quos architecto, totam nam numquam minima non? Ipsam asperiores itaque aspernatur quidem, sed cumque corrupti placeat assumenda quo odio quod maxime ex, sit blanditiis neque amet mollitia magnam, ad iste obcaecati rem perferendis distinctio. Doloribus soluta placeat sequi officia dolor fugiat impedit iste amet ipsa nesciunt, saepe iure veritatis deserunt odio maxime vero distinctio voluptatem, tempora odit est unde architecto qui. Illum quasi officiis at, repudiandae corporis sint saepe suscipit reiciendis cum nulla nihil itaque deserunt cumque labore asperiores rem eos ea, ratione quod voluptatum omnis iste sequi facere. Ut dolores blanditiis dolorum amet, obcaecati maiores? Quis labore nesciunt repudiandae eveniet quam quisquam molestias, sapiente minima! Sint illo voluptatum repellendus maxime reiciendis, voluptates perferendis quis voluptatem magni non error! Blanditiis, excepturi nihil esse dolore unde vitae at praesentium eius dolorem iste nisi amet rem dicta a? Suscipit facilis veniam doloribus explicabo! Modi error reprehenderit et at magnam rerum veritatis ratione quisquam eum deserunt iusto suscipit voluptatibus repellendus maiores, ullam provident ut esse rem enim beatae incidunt earum perspiciatis quae! Animi iste, modi ab nesciunt, vitae repellendus in eius laborum inventore quas repudiandae consequuntur praesentium mollitia ducimus eveniet autem quos exercitationem voluptatem deserunt? Quidem soluta quis fugit qui animi ex veritatis dolore placeat ullam, eligendi et nobis repellendus modi quisquam, nesciunt voluptatibus pariatur. Laborum deserunt, illum dolor ipsam pariatur molestias debitis sed iste. Recusandae voluptatem adipisci ipsam facilis ullam quibusdam eligendi? Sequi incidunt ipsam cupiditate veritatis, beatae rerum nesciunt magni maxime possimus quasi eveniet, necessitatibus atque tenetur commodi nisi cumque numquam, voluptates labore dignissimos aliquid. Optio veniam eos et minus! Voluptate dolor nisi cupiditate, nemo nihil assumenda aspernatur aut possimus, debitis asperiores obcaecati earum exercitationem deleniti veritatis? Fugiat deserunt consequatur quibusdam libero harum consequuntur voluptas officia nesciunt quidem atque maiores quaerat beatae, eaque iste? Voluptatibus provident odit pariatur necessitatibus laborum quasi cumque mollitia minus architecto maxime sunt modi, officiis eos aliquid? Blanditiis fugiat ab deserunt quod exercitationem quo adipisci dolores dolorum praesentium, ratione facere saepe neque explicabo repudiandae, modi totam voluptates hic non necessitatibus eveniet maxime enim nisi. Laboriosam eligendi ratione praesentium enim corrupti voluptate, asperiores, officia vero, quia facere corporis vel fugit reiciendis mollitia explicabo hic consequatur officiis quis? Delectus maiores praesentium enim explicabo cum odit est suscipit qui tenetur, quos, modi ducimus doloribus aliquid hic, temporibus et aliquam consectetur perspiciatis corrupti. Similique mollitia laboriosam, blanditiis necessitatibus corporis ex vitae tenetur et facilis soluta saepe nisi consequuntur expedita, minima quibusdam quasi ratione quod quo libero officia aut labore cumque! At natus doloremque nam ullam, minus vel modi aperiam mollitia deserunt numquam non, id explicabo porro sed perferendis placeat est sunt ab molestiae facere expedita nulla. Suscipit, tempore tenetur sint tempora aut earum consequuntur dolore et nesciunt repudiandae facilis animi culpa, distinctio minima natus odit velit commodi reiciendis, asperiores illo quia inventore debitis. Amet, minima aliquid labore ex quia aperiam assumenda tempore ipsa officia non animi eos illum nulla optio fuga reprehenderit recusandae, culpa quo magni consequuntur perspiciatis. Itaque voluptas, vel animi ex aperiam, aliquam quos facilis in sapiente quasi tempora assumenda corporis rerum distinctio a quibusdam! Facilis earum minima quam quo molestiae! Ex qui, totam quis voluptatum voluptates sapiente cupiditate earum. Veritatis totam, voluptas explicabo voluptate itaque perspiciatis officia soluta distinctio provident excepturi optio non vitae maxime nam odio reprehenderit corrupti aliquam. Odio a modi provident illo est nam saepe doloremque. Nobis, dolor voluptas voluptates enim laboriosam ratione in praesentium totam aut, omnis debitis culpa consequatur ex nostrum cumque cum aliquid reiciendis? Asperiores, minima aspernatur porro ea deserunt quasi, numquam animi provident fugiat pariatur facere minus est iste fugit sed nostrum quod nisi expedita et harum. Accusantium adipisci reprehenderit eligendi tempore quia sequi animi non qui, voluptates perspiciatis, hic nesciunt deserunt fuga, tenetur saepe ullam expedita totam necessitatibus veniam quam assumenda ipsam. Eveniet, veritatis. Accusamus, ex laudantium. Doloremque neque similique ipsum, ducimus quia eos necessitatibus, recusandae dolorum perspiciatis nobis aperiam. Veniam autem officia unde sequi in cum corporis odit ducimus repellendus recusandae! Aperiam debitis, molestias consequatur iure at, suscipit laborum deserunt dignissimos qui animi consequuntur ad neque! Iusto maxime quibusdam est perspiciatis optio animi soluta quia. Accusamus fugiat, quis ratione voluptatum consequatur, vitae quod earum in nihil maiores, commodi id ea soluta? Corrupti aut blanditiis illo doloribus esse minima obcaecati autem nostrum! Dolores ab atque unde, in odit repellendus molestiae possimus, repudiandae iure velit blanditiis. Ut, dolorum! Dolorem facilis molestias praesentium autem obcaecati dolorum illo, asperiores magni quidem voluptas consequuntur dolore reiciendis, voluptates expedita officiis, explicabo molestiae excepturi cupiditate deserunt at modi! Natus fuga repudiandae expedita doloremque a cupiditate libero laboriosam cumque temporibus hic aliquam voluptas totam illo nemo odio vel nesciunt ad voluptates error, tempore eos, officiis architecto voluptatibus. Recusandae ratione illum sed aliquam libero neque dolore unde necessitatibus cum itaque porro, facilis ducimus atque ex et officiis error voluptate nemo enim cupiditate repellat ab reiciendis incidunt praesentium. Exercitationem voluptatibus soluta, consequuntur officia consequatur repellat quod ipsam. Molestias incidunt itaque modi quos ab, iure pariatur placeat blanditiis tempore deserunt quia molestiae assumenda consectetur ducimus sit atque facere nihil! Veritatis quasi perferendis repellat veniam, magnam laboriosam numquam reprehenderit odio atque, ducimus laudantium nesciunt, minima beatae aliquid tenetur? Nam fuga nostrum ut non in sit earum minus, qui eaque odit, illum iure nemo maxime at architecto. Dolorem soluta, sunt neque harum itaque eveniet maiores molestias quam minus quia exercitationem! Deserunt iure quae quod! Nobis animi neque cumque corrupti dolor reprehenderit labore, officia, odio, alias laborum distinctio nesciunt? Ratione nobis est iste eligendi, dolore soluta hic veniam fugiat quis eveniet, minus fugit veritatis vel aliquam facilis doloribus dolor architecto qui? Est sit animi repellendus dignissimos, ratione voluptatibus voluptates, autem veniam quidem nostrum quisquam optio eius asperiores. Hic illo sunt est ad in odio exercitationem fuga cupiditate ex mollitia eius consequuntur similique harum error itaque earum atque molestiae nesciunt blanditiis, laborum, omnis aspernatur perspiciatis! Aut illo ut reiciendis in iste sequi magnam cum sit ipsa, est et tempora laboriosam cumque vitae quam hic dolores atque obcaecati labore cupiditate mollitia, temporibus ea? Porro enim voluptatum fuga praesentium. Nam eum tenetur modi possimus nobis? Cum incidunt ducimus facere recusandae architecto veniam laudantium nihil quae possimus non. Aut ex culpa ab fugit nulla nesciunt maxime numquam a necessitatibus laborum beatae suscipit corporis repudiandae dolorem aspernatur, corrupti voluptate esse voluptatum vero autem ea, unde pariatur. Libero eum repellendus inventore itaque temporibus mollitia impedit saepe sapiente enim corrupti. Quo, facere. Beatae modi necessitatibus commodi nam laudantium, libero natus aliquam aut sed dolore perferendis ducimus tempore. Id, ducimus consectetur. Sapiente placeat non ipsam quos quia fugiat excepturi laborum, accusantium soluta voluptas hic! Tempora labore omnis repudiandae quaerat distinctio provident modi quisquam fugit placeat culpa expedita similique non eligendi eos exercitationem quo sed dolor aperiam ex, perspiciatis alias! Quas aspernatur maxime tempora quos sequi ea deserunt nemo repudiandae reiciendis iste placeat possimus, voluptates voluptate, veritatis nostrum quisquam provident nihil. Nisi fugit deserunt dolor qui, nihil mollitia recusandae doloribus officia temporibus reiciendis vitae incidunt similique, repudiandae, dicta tempora corrupti rem ex saepe tempore molestias? Ipsam quos maxime neque harum!"
    });
}

// EXTERNAL MODULE: ./styles/FooterFull.module.scss
var FooterFull_module = __webpack_require__(74);
var FooterFull_module_default = /*#__PURE__*/__webpack_require__.n(FooterFull_module);
;// CONCATENATED MODULE: external "dayjs"
const external_dayjs_namespaceObject = require("dayjs");
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_namespaceObject);
;// CONCATENATED MODULE: ./components/footer/FooterFull.js



function FooterFull() {
    const goToTheTop = ()=>{
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    const tlsCreationDate = external_dayjs_default()("1960-10-24");
    const currentDate = external_dayjs_default()();
    const tlsEra = currentDate.diff(tlsCreationDate, "year");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (FooterFull_module_default()).footer__wrapper__full,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (FooterFull_module_default()).socials__wrapper__list,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://facebook.com/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (FooterFull_module_default()).socials__icon__facebook,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M17.525,9H14V7c0-1.032,0.084-1.682,1.563-1.682h1.868v-3.18C16.522,2.044,15.608,1.998,14.693,2 C11.98,2,10,3.657,10,6.699V9H7v4l3-0.001V22h4v-9.003l3.066-0.001L17.525,9z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://instagram.com/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (FooterFull_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M 8 3 C 5.239 3 3 5.239 3 8 L 3 16 C 3 18.761 5.239 21 8 21 L 16 21 C 18.761 21 21 18.761 21 16 L 21 8 C 21 5.239 18.761 3 16 3 L 8 3 z M 18 5 C 18.552 5 19 5.448 19 6 C 19 6.552 18.552 7 18 7 C 17.448 7 17 6.552 17 6 C 17 5.448 17.448 5 18 5 z M 12 7 C 14.761 7 17 9.239 17 12 C 17 14.761 14.761 17 12 17 C 9.239 17 7 14.761 7 12 C 7 9.239 9.239 7 12 7 z M 12 9 A 3 3 0 0 0 9 12 A 3 3 0 0 0 12 15 A 3 3 0 0 0 15 12 A 3 3 0 0 0 12 9 z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://twitter.com/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (FooterFull_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M22,3.999c-0.78,0.463-2.345,1.094-3.265,1.276c-0.027,0.007-0.049,0.016-0.075,0.023c-0.813-0.802-1.927-1.299-3.16-1.299 c-2.485,0-4.5,2.015-4.5,4.5c0,0.131-0.011,0.372,0,0.5c-3.353,0-5.905-1.756-7.735-4c-0.199,0.5-0.286,1.29-0.286,2.032 c0,1.401,1.095,2.777,2.8,3.63c-0.314,0.081-0.66,0.139-1.02,0.139c-0.581,0-1.196-0.153-1.759-0.617c0,0.017,0,0.033,0,0.051 c0,1.958,2.078,3.291,3.926,3.662c-0.375,0.221-1.131,0.243-1.5,0.243c-0.26,0-1.18-0.119-1.426-0.165 c0.514,1.605,2.368,2.507,4.135,2.539c-1.382,1.084-2.341,1.486-5.171,1.486H2C3.788,19.145,6.065,20,8.347,20 C15.777,20,20,14.337,20,8.999c0-0.086-0.002-0.266-0.005-0.447C19.995,8.534,20,8.517,20,8.499c0-0.027-0.008-0.053-0.008-0.08 c-0.003-0.136-0.006-0.263-0.009-0.329c0.79-0.57,1.475-1.281,2.017-2.091c-0.725,0.322-1.503,0.538-2.32,0.636 C20.514,6.135,21.699,4.943,22,3.999z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "https://t.me/TheLaSallian",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (FooterFull_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 50 50",
                            width: "24px",
                            height: "24px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M46.137,6.552c-0.75-0.636-1.928-0.727-3.146-0.238l-0.002,0C41.708,6.828,6.728,21.832,5.304,22.445 c-0.259,0.09-2.521,0.934-2.288,2.814c0.208,1.695,2.026,2.397,2.248,2.478l8.893,3.045c0.59,1.964,2.765,9.21,3.246,10.758 c0.3,0.965,0.789,2.233,1.646,2.494c0.752,0.29,1.5,0.025,1.984-0.355l5.437-5.043l8.777,6.845l0.209,0.125 c0.596,0.264,1.167,0.396,1.712,0.396c0.421,0,0.825-0.079,1.211-0.237c1.315-0.54,1.841-1.793,1.896-1.935l6.556-34.077 C47.231,7.933,46.675,7.007,46.137,6.552z M22,32l-3,8l-3-10l23-17L22,32z"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "mailto:me@thelasallian.com",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            className: (FooterFull_module_default()).socials__icon__svg,
                            xmlns: "http://www.w3.org/2000/svg",
                            height: "48",
                            viewBox: "0 96 960 960",
                            width: "48",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M142.152 901.978q-27.599 0-47.865-20.265-20.265-20.266-20.265-47.865V318.152q0-27.697 20.265-48.033 20.266-20.337 47.865-20.337h675.696q27.697 0 48.033 20.337 20.337 20.336 20.337 48.033v515.696q0 27.599-20.337 47.865-20.336 20.265-48.033 20.265H142.152ZM480 601.652l337.848-223v-60.5L480 536.152l-337.848-218v60.5l337.848 223Z"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (FooterFull_module_default()).footer__details__wrapper,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (FooterFull_module_default()).details__text__container,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: "The LaSallian"
                        }),
                        " is the official student publication of De La Salle University. It is of the students, by the students, and for the students. Our student writers, photographers, videographers, artists, and web managers are committed to the ",
                        tlsEra,
                        "-year tradition of journalistic excellence and issue-oriented critical thinking.",
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        "502-A Bro. Connon Hall, De La Salle University, 2401 Taft Avenue",
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        "Manila, Philippines"
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (FooterFull_module_default()).ender__details__wrapper,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: "Powered by Depresso"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onClick: goToTheTop,
                        className: (FooterFull_module_default()).ender__toTheTop__link,
                        children: "To the top"
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/footer/Footer.js



function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx(FooterFull, {});
}

;// CONCATENATED MODULE: ./pages/index.js





function Home({ sections  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: "The LaSallian — The bastion of issue-oriented critical thinking"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Body, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
                ]
            })
        ]
    });
}
async function getServerSideProps({ req , res  }) {
    res.setHeader("Cache-Control", "public, s-maxage=10, stale-while-revalidate=59");
    const universityResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=4");
    const universityData = await universityResponse.json();
    const menagerieResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=8");
    const menagerieData = await menagerieResponse.json();
    const sportsResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=6");
    const sportsData = await sportsResponse.json();
    const vanguardResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=1883");
    const vanguardData = await vanguardResponse.json();
    const opinionResponse = await fetch("https://thelasallian.com/wp-json/wp/v2/posts?_fields=id,authors,excerpt,title,slug,categories,jetpack_featured_media_url&per_page=6&categories=5");
    const opinionData = await opinionResponse.json();
    return {
        props: {
            sections: [
                {
                    name: "University",
                    category: 4,
                    articles: universityData
                },
                {
                    name: "Menagerie",
                    category: 8,
                    articles: menagerieData
                },
                {
                    name: "Sports",
                    category: 6,
                    articles: sportsData
                },
                {
                    name: "Vanguard",
                    category: 1883,
                    articles: vanguardData
                },
                {
                    name: "Opinions",
                    category: 5,
                    articles: opinionData
                }
            ]
        }
    };
}


/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(866));
module.exports = __webpack_exports__;

})();