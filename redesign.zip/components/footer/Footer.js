import React from "react";
import FooterFull from "./FooterFull";

export default function Footer() {
    return (
        <FooterFull/>
    );
}