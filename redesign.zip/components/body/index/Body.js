import React from "react";
import BodyFull from "./BodyFull";

export default function Body({sections}) {
    return (
        <BodyFull sections={sections}/>
    );
}